use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::post('/signup', [AuthController::class, 'signup']);
Route::post('/login', [AuthController::class, 'login']);

// Protected route (JWT required)
Route::middleware('auth:api')->get('/admin/dashboard', function () {
    return response()->json(['message' => 'Welcome, Admin!']);
});
