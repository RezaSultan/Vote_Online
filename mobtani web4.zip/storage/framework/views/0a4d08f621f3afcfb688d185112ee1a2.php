<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به حساب کاربری</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 420px;
            padding: 40px 30px;
            transition: transform 0.3s ease;
        }
        
        .login-container:hover {
            transform: translateY(-5px);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 8px;
        }
        
        .login-header p {
            color: #666;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #4d90fe;
            box-shadow: 0 0 0 2px rgba(77, 144, 254, 0.2);
            outline: none;
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background: linear-gradient(135deg, #5a0db5 0%, #1c68e6 100%);
            box-shadow: 0 5px 15px rgba(37, 117, 252, 0.4);
        }
        
        .login-footer {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .login-footer a {
            color: #2575fc;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }
        
        .login-footer a:hover {
            color: #1c68e6;
            text-decoration: underline;
        }
        
        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
        }
        
        .remember-me input {
            margin-left: 8px;
        }
        
        .forgot-password {
            color: #2575fc;
            text-decoration: none;
            font-size: 14px;
        }
        
        .forgot-password:hover {
            text-decoration: underline;
        }
        
        .error {
            color: #d9534f;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            padding: 10px 15px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .error ul {
            margin: 0;
            padding-right: 20px;
        }
        
        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }
            
            .remember-forgot {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .forgot-password {
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h2>ورود به حساب کاربری</h2>
            <p>لطفا اطلاعات خود را وارد کنید</p>
        </div>
        
        <!-- نمایش خطاهای اعتبارسنجی -->
        <div id="clientErrors" class="error" style="display:none;"></div>
        
        <?php if($errors->any()): ?>
            <div class="error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form action="<?php echo e(url('/login')); ?>" method="POST" id="loginForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email">ایمیل</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="ایمیل خود را وارد کنید" required value="<?php echo e(old('email')); ?>">
            </div>
            
            <div class="form-group">
                <label for="password">رمز عبور</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="رمز عبور خود را وارد کنید" required>
            </div>
            
            <div class="remember-forgot">
                <div class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">مرا به خاطر بسپار</label>
                </div>
                <a href="#" class="forgot-password">رمز عبور را فراموش کرده اید؟</a>
            </div>
            
            <button type="submit" class="btn-login">ورود</button>
        </form>
        
        <div class="login-footer">
            <p>ثبت‌نام نکرده‌اید؟ <a href="<?php echo e(url('/register')); ?>">ثبت‌نام کنید</a></p>
        </div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            // پاک کردن خطاهای قبلی
            document.getElementById('clientErrors').style.display = 'none';
            document.getElementById('clientErrors').innerHTML = '';
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errors = [];
            
            // اعتبارسنجی ایمیل
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                errors.push('لطفا یک ایمیل معتبر وارد کنید');
            }
            
            // اعتبارسنجی رمز عبور
            if (password.length < 6) {
                errors.push('رمز عبور باید حداقل ۶ کاراکتر باشد');
            }
            
            // اگر خطایی وجود دارد، فرم ارسال نمی‌شود
            if (errors.length > 0) {
                e.preventDefault();
                const errorContainer = document.getElementById('clientErrors');
                errorContainer.innerHTML = '<ul>' + errors.map(error => '<li>' + error + '</li>').join('') + '</ul>';
                errorContainer.style.display = 'block';
                
                // اسکرول به بالای فرم برای نمایش خطاها
                errorContainer.scrollIntoView({ behavior: 'smooth' });
            }
        });
    </script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\my\resources\views/auth/login.blade.php ENDPATH**/ ?>