<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت نام</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f0f2f5;
            font-family: "Vazirmatn", sans-serif;
        }
        .register-card {
            width: 400px;
            margin: 80px auto;
            padding: 30px;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .register-btn {
            background: #0d6efd;
            color: #fff;
            width: 100%;
        }
        .register-btn:hover {
            background: #0b5ed7;
        }
    </style>
</head>

<body>

<div class="register-card">
    <h3 class="text-center mb-4">ثبت نام کاربر</h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>خطا!</strong>
            <ul class="mt-2 mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('/register')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">نام</label>
            <input type="text" name="name" class="form-control" required value="<?php echo e(old('name')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">ایمیل</label>
            <input type="email" name="email" class="form-control" required value="<?php echo e(old('email')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">رمز عبور</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">تکرار رمز عبور</label>
            <input type="password" name="password_confirmation" class="form-control" required>
        </div>

        <button type="submit" class="btn register-btn">ثبت نام</button>

        <div class="text-center mt-3">
            <a href="/login">حساب دارید؟ ورود</a>
        </div>
    </form>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\my\resources\views/auth/register.blade.php ENDPATH**/ ?>