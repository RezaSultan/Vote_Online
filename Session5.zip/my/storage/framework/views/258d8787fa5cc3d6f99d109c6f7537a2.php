

<?php $__env->startSection('content'); ?>
    <div class="container py-5">

        <h2 class="mb-4 text-center">Public Surveys</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($surveys->count() > 0): ?>
            <div class="row">
                <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4">
                        <div class="card shadow">

                            <div class="card-body">
                                <h5><?php echo e($survey->title); ?></h5>
                                <p><?php echo e($survey->question); ?></p>

                                <a href="<?php echo e(route('survey.show', $survey->id)); ?>" class="btn btn-primary btn-sm">
                                    Vote Now
                                </a>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p>No active surveys found.</p>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my\resources\views/public.blade.php ENDPATH**/ ?>