

<?php $__env->startSection('content'); ?>
<div class="container mt-5">

    <div class="d-flex justify-content-between">
        <h2>داشبورد مدیر</h2>

        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger">خروج</button>
        </form>
    </div>

    <hr>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.surveys.create')); ?>" class="btn btn-primary mb-3">
        ایجاد نظرسنجی جدید
    </a>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>عنوان</th>
            <th>سؤال</th>
            <th>گزینه‌ها</th>
        </tr>
        </thead>
        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($survey->title); ?></td>
            <td><?php echo e($survey->question); ?></td>
            <td>
                <?php $__currentLoopData = $survey->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>- <?php echo e($opt->option_text); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center">هیچ نظرسنجی وجود ندارد</td>
            </tr>
        <?php endif; ?>

        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>