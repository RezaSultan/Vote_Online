<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($survey->title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Vazirmatn', sans-serif;
            min-height: 100vh;
            padding: 20px 0;
        }
        
        .survey-container {
            max-width: 700px;
            margin: 0 auto;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-header {
            background: linear-gradient(45deg, #4e73df, #224abe);
            color: white;
            padding: 20px 25px;
            border: none;
            position: relative;
        }
        
        .card-header h5 {
            font-weight: 700;
            margin: 0;
            font-size: 1.4rem;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .survey-question {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px dashed #e0e0e0;
        }
        
        .form-check {
            margin-bottom: 18px;
            padding: 15px;
            border-radius: 10px;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .form-check:hover {
            background-color: #e9ecef;
            transform: translateX(5px);
        }
        
        .form-check-input {
            margin-left: 15px;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .form-check-input:checked {
            background-color: #4e73df;
            border-color: #4e73df;
        }
        
        .form-check-label {
            font-size: 1.1rem;
            cursor: pointer;
            color: #444;
        }
        
        .btn-vote {
            background: linear-gradient(45deg, #36b9cc, #1a78c2);
            border: none;
            border-radius: 50px;
            padding: 12px 35px;
            font-weight: 600;
            font-size: 1.1rem;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(54, 185, 204, 0.3);
        }
        
        .btn-vote:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(54, 185, 204, 0.4);
            background: linear-gradient(45deg, #2c9faf, #165a92);
        }
        
        .btn-back {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .btn-back:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-50%) scale(1.1);
        }
        
        .btn-back i {
            font-size: 1.2rem;
        }
        
        @media (max-width: 576px) {
            .card-body {
                padding: 20px;
            }
            
            .survey-question {
                font-size: 1.1rem;
            }
            
            .form-check {
                padding: 12px;
            }
            
            .btn-vote {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container survey-container">
    <div class="card">
        <div class="card-header">
            <button class="btn-back" onclick="history.back()" aria-label="بازگشت">
                <i class="bi bi-arrow-right"></i>
            </button>
            <h5><?php echo e($survey->title); ?></h5>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('survey.vote')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="survey_id" value="<?php echo e($survey->id); ?>">

                <h6 class="survey-question"><?php echo e($survey->question); ?></h6>

                <?php $__currentLoopData = $survey->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input"
                               type="radio"
                               name="option_id"
                               value="<?php echo e($option->id); ?>"
                               id="option<?php echo e($option->id); ?>">

                        <label class="form-check-label" for="option<?php echo e($option->id); ?>">
                            <?php echo e($option->option_text); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="d-grid gap-2 mt-4">
                    <button type="submit" class="btn btn-vote">
                        <i class="bi bi-check-circle-fill ms-2"></i> ثبت رأی
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\my\resources\views/vote.blade.php ENDPATH**/ ?>