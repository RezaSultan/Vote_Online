<!DOCTYPE html>
<html>
    <head></head>

    <body>
        <form action="rect2.php" method="GET">
            tool : <br>
            <input type="number" name="tool"> <br>
             arz : <br>
            <input type="number" name="arz"> <br>
             tool : <br>
            <input type="submit" value="GET"> <br>
        </form>
    </body>
</html>