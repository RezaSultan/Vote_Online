<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد کاربری</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Vazirmatn', sans-serif;
        }

        body {
            background: #f0f2f5;
            color: #333;
        }

        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            right: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
            transition: all 0.3s ease;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h3 {
            color: white;
            font-weight: 700;
            font-size: 24px;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .sidebar-menu ul {
            list-style: none;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-right-color: white;
        }

        .sidebar-menu i {
            margin-left: 15px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            margin-right: 260px;
            padding: 20px;
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: white;
            border-radius: 15px;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #333;
        }

        .header-actions {
            display: flex;
            align-items: center;
        }

        .notification-btn {
            position: relative;
            background: #f8f9fa;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .notification-btn:hover {
            background: #e9ecef;
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            left: -5px;
            background: #dc3545;
            color: white;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: bold;
        }

        .user-profile {
            display: flex;
            align-items: center;
            position: relative;
        }

        .user-profile img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            margin-left: 15px;
            border: 2px solid #f0f2f5;
        }

        .user-info h4 {
            font-size: 16px;
            margin-bottom: 2px;
        }

        .user-info p {
            font-size: 13px;
            color: #666;
            margin: 0;
        }

        .user-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            min-width: 200px;
            padding: 10px 0;
            margin-top: 10px;
            display: none;
            z-index: 1000;
        }

        .user-dropdown.show {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .user-dropdown a:hover {
            background: #f8f9fa;
            color: #667eea;
        }

        .user-dropdown .divider {
            height: 1px;
            background: #f0f2f5;
            margin: 10px 0;
        }

        .logout-btn {
            color: #dc3545 !important;
        }

        .logout-btn:hover {
            background: #f8d7da !important;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .stat-card.blue::before {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .stat-card.green::before {
            background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
        }

        .stat-card.orange::before {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .stat-card.purple::before {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-title {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }

        .stat-card.blue .stat-icon {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .stat-card.green .stat-icon {
            background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
        }

        .stat-card.orange .stat-icon {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .stat-card.purple .stat-icon {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-change {
            font-size: 13px;
            display: flex;
            align-items: center;
        }

        .stat-change.positive {
            color: #28a745;
        }

        .stat-change.negative {
            color: #dc3545;
        }

        /* Content Cards */
        .content-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow: hidden;
        }

        .card-header-custom {
            padding: 20px 25px;
            border-bottom: 1px solid #f0f2f5;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header-custom h3 {
            font-size: 18px;
            font-weight: 600;
            margin: 0;
        }

        .card-header-custom .btn {
            font-size: 13px;
            padding: 6px 15px;
        }

        .card-body-custom {
            padding: 25px;
        }

        /* Survey List */
        .survey-list {
            list-style: none;
        }

        .survey-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #f0f2f5;
        }

        .survey-item:last-child {
            border-bottom: none;
        }

        .survey-title {
            font-weight: 500;
            color: #333;
        }

        .survey-meta {
            display: flex;
            align-items: center;
            margin-top: 5px;
        }

        .survey-meta span {
            font-size: 13px;
            color: #666;
            margin-left: 15px;
            display: flex;
            align-items: center;
        }

        .survey-meta i {
            margin-left: 5px;
            font-size: 14px;
        }

        .btn-vote {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-vote:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }

        /* Recent Activities */
        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            align-items: flex-start;
            padding: 15px 0;
            border-bottom: 1px solid #f0f2f5;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: 15px;
            flex-shrink: 0;
        }

        .activity-icon.survey {
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
        }

        .activity-icon.vote {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .activity-icon.comment {
            background: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }

        .activity-content {
            flex: 1;
        }

        .activity-title {
            font-weight: 500;
            margin-bottom: 3px;
        }

        .activity-time {
            font-size: 13px;
            color: #666;
        }

        /* Chart Placeholder */
        .chart-placeholder {
            height: 250px;
            background: #f8f9fa;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            font-size: 16px;
        }

        /* Mobile Responsiveness */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
            }

            .sidebar-header h3,
            .sidebar-header p,
            .sidebar-menu span {
                display: none;
            }

            .sidebar-menu a {
                justify-content: center;
                padding: 15px 0;
            }

            .sidebar-menu i {
                margin: 0;
            }

            .main-content {
                margin-right: 80px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-right: 0;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
            }

            .header-actions {
                margin-top: 15px;
                width: 100%;
                justify-content: space-between;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>پنل کاربری</h3>
            <p>خوش آمدید</p>
        </div>

        <div class="sidebar-menu">
            <ul>
                <li><a href="#" class="active"><i class="fas fa-home"></i> <span>داشبورد</span></a></li>
                <li><a href="#"><i class="fas fa-poll"></i> <span>نظرسنجی‌ها</span></a></li>
                <li><a href="#"><i class="fas fa-chart-bar"></i> <span>گزارش‌ها</span></a></li>
                <li><a href="#"><i class="fas fa-users"></i> <span>کاربران</span></a></li>
                <li><a href="#"><i class="fas fa-cog"></i> <span>تنظیمات</span></a></li>
                <li><a href="#"><i class="fas fa-question-circle"></i> <span>راهنما</span></a></li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <h1>داشبورد</h1>

            <div class="header-actions">
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </button>

                <div class="user-profile">
                    <img src="{{ Auth::user()->avatar ?? 'https://randomuser.me/api/portraits/men/32.jpg' }}"
                        alt="کاربر">
                    <div class="user-info">
                        <h4>{{ Auth::user()->name }}</h4>
                        <p>{{ Auth::user()->email }}</p>
                    </div>

                    <div class="user-dropdown" id="userDropdown">
                        <a href="#"><i class="fas fa-user"></i> پروفایل کاربری</a>
                        <a href="#"><i class="fas fa-cog"></i> تنظیمات حساب</a>
                        <div class="divider"></div>
                        <form action="{{ route('logout') }}" method="POST">
                            @csrf
                            <button type="submit" class="logout-btn"
                                style="background: none; border: none; width: 100%; text-align: right; padding: 10px 20px; cursor: pointer;">
                                <i class="fas fa-sign-out-alt"></i> خروج از حساب
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-container">
            <div class="stat-card blue">
                <div class="stat-header">
                    <div class="stat-title">کل نظرسنجی‌ها</div>
                    <div class="stat-icon">
                        <i class="fas fa-poll"></i>
                    </div>
                </div>
                <div class="stat-value">24</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i> 12% از ماه گذشته
                </div>
            </div>

            <div class="stat-card green">
                <div class="stat-header">
                    <div class="stat-title">رأی‌های امروز</div>
                    <div class="stat-icon">
                        <i class="fas fa-vote-yea"></i>
                    </div>
                </div>
                <div class="stat-value">142</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i> 8% از دیروز
                </div>
            </div>

            <div class="stat-card orange">
                <div class="stat-header">
                    <div class="stat-title">کاربران فعال</div>
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="stat-value">1,248</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i> 5% از هفته گذشته
                </div>
            </div>

            <div class="stat-card purple">
                <div class="stat-header">
                    <div class="stat-title">نرخ مشارکت</div>
                    <div class="stat-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                </div>
                <div class="stat-value">68%</div>
                <div class="stat-change negative">
                    <i class="fas fa-arrow-down"></i> 2% از ماه گذشته
                </div>
            </div>
        </div>

        <!-- Active Surveys Section -->
        <div class="content-card">
            <div class="card-header-custom">
                <h3>نظرسنجی‌های فعال</h3>
                <a href="#" class="btn btn-sm btn-outline-primary">مشاهده همه</a>
            </div>
            <div class="card-body-custom">
                @if($surveys->count())
                    <ul class="survey-list">
                        @foreach($surveys as $s)
                            <li class="survey-item">
                                <div>
                                    <div class="survey-title">{{ $s->title }}</div>
                                    <div class="survey-meta">
                                        <span><i class="fas fa-calendar"></i> {{ $s->created_at->format('Y/m/d') }}</span>
                                        <span><i class="fas fa-users"></i> {{ $s->votes_count }} رأی</span>
                                    </div>
                                </div>
                                <a href="{{ route('survey.show', $s->id) }}" class="btn-vote">رأی دادن</a>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <p class="text-center py-4 text-muted">فعلاً نظرسنجی فعالی وجود ندارد.</p>
                @endif
            </div>
        </div>

        <!-- Recent Activities and Chart -->
        <div class="row">
            <div class="col-md-6">
                <div class="content-card">
                    <div class="card-header-custom">
                        <h3>فعالیت‌های اخیر</h3>
                    </div>
                    <div class="card-body-custom">
                        <ul class="activity-list">
                            <li class="activity-item">
                                <div class="activity-icon survey">
                                    <i class="fas fa-poll"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">نظرسنجی جدید "رضایت کاربران" ایجاد شد</div>
                                    <div class="activity-time">2 ساعت پیش</div>
                                </div>
                            </li>
                            <li class="activity-item">
                                <div class="activity-icon vote">
                                    <i class="fas fa-vote-yea"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">25 رأی جدید در نظرسنجی "محصولات محبوب"</div>
                                    <div class="activity-time">5 ساعت پیش</div>
                                </div>
                            </li>
                            <li class="activity-item">
                                <div class="activity-icon comment">
                                    <i class="fas fa-comment"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">نظر جدید برای نظرسنجی "بهبود خدمات"</div>
                                    <div class="activity-time">1 روز پیش</div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="content-card">
                    <div class="card-header-custom">
                        <h3>نمودار پیشرفت</h3>
                    </div>
                    <div class="card-body-custom">
                        <div class="chart-placeholder">
                            <i class="fas fa-chart-line fa-3x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle user dropdown
        document.addEventListener('DOMContentLoaded', function () {
            const userProfile = document.querySelector('.user-profile');
            const userDropdown = document.getElementById('userDropdown');

            userProfile.addEventListener('click', function (e) {
                e.stopPropagation();
                userDropdown.classList.toggle('show');
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function () {
                userDropdown.classList.remove('show');
            });

            // Prevent dropdown from closing when clicking inside
            userDropdown.addEventListener('click', function (e) {
                e.stopPropagation();
            });
        });
    </script>
</body>

</html>