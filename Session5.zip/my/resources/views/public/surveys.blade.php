<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>{{ $survey->title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5>{{ $survey->title }}</h5>
        </div>

        <div class="card-body">
            <form action="{{ route('survey.vote') }}" method="POST">
                @csrf

                <input type="hidden" name="survey_id" value="{{ $survey->id }}">

                <h6 class="mb-3">{{ $survey->question }}</h6>

                @foreach($survey->options as $option)
                    <div class="form-check mb-2">
                        <input class="form-check-input"
                               type="radio"
                               name="option_id"
                               value="{{ $option->id }}"
                               id="option{{ $option->id }}">

                        <label class="form-check-label" for="option{{ $option->id }}">
                            {{ $option->option_text }}
                        </label>
                    </div>
                @endforeach

                <button type="submit" class="btn btn-success mt-3">
                    ثبت رأی
                </button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
