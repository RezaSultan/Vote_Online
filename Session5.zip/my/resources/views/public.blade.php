@extends('layouts.app')

@section('content')
<div class="container py-5">

    <h2 class="mb-4 text-center">Public Surveys</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if($surveys->count() > 0)
        <div class="row">
            @foreach($surveys as $survey)
                <div class="col-md-4 mb-4">
                    <div class="card shadow">

                        <div class="card-body">
                            <h5>{{ $survey->title }}</h5>
                            <p>{{ $survey->question }}</p>

                            <a href="{{ route('survey.show',$survey->id) }}"
                               class="btn btn-primary btn-sm">
                                Vote Now
                            </a>
                        </div>

                    </div>
                </div>
            @endforeach
        </div>
    @else
        <p>No active surveys found.</p>
    @endif

</div>
@endsection
