<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نظرسنجی‌های فعال</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body{
            background:#f4f6f9;
            font-family: Tahoma, sans-serif;
        }
        .survey-card{
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
            border: none;
        }
        .survey-header{
            background:#0d6efd;
            color:#fff;
            border-radius:20px 20px 0 0;
        }
        .vote-btn{
            border-radius:30px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="mb-4 text-center fw-bold">📊 لیست نظرسنجی‌های فعال</h2>

    @if($surveys->count() > 0)

        <div class="row g-4">

            @foreach($surveys as $survey)
            <div class="col-md-6 col-lg-4">
                <div class="card survey-card h-100">

                    <div class="card-header survey-header text-center py-3">
                        <h5 class="mb-0">{{ $survey->title }}</h5>
                    </div>

                    <div class="card-body d-flex flex-column">
                        <p class="text-muted text-center">
                            {{ $survey->question }}
                        </p>

                        <div class="mt-auto text-center">
                            <a href="{{ url('/survey/'.$survey->id) }}" class="btn btn-primary vote-btn px-4 py-2">
                                رأی دادن
                            </a>
                        </div>
                    </div>

                </div>
            </div>
            @endforeach

        </div>

    @else
        <div class="alert alert-warning text-center">
            در حال حاضر هیچ نظرسنجی فعالی وجود ندارد.
        </div>
    @endif
</div>

</body>
</html>
