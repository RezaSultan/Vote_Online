@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h2 class="mb-4">ایجاد نظرسنجی جدید</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
               <p>{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <form action="{{ route('admin.surveys.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label>عنوان نظرسنجی</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>سؤال</label>
            <textarea name="question" class="form-control" rows="3" required></textarea>
        </div>

        <label>گزینه‌ها:</label>
        <div id="option-box">
            <input type="text" name="options[]" class="form-control mb-2" placeholder="گزینه 1">
            <input type="text" name="options[]" class="form-control mb-2" placeholder="گزینه 2">
        </div>

        <button type="button" class="btn btn-secondary my-2" onclick="addOption()">افزودن گزینه</button>

        <button type="submit" class="btn btn-success">ذخیره نظرسنجی</button>

    </form>
</div>

<script>
    function addOption(){
        let input = document.createElement("input");
        input.type = "text";
        input.name = "options[]";
        input.className = "form-control mb-2";
        document.getElementById("option-box").appendChild(input);
    }
</script>
@endsection
