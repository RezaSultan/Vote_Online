<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ $survey->title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <a href="{{ route('surveys.public') }}" class="btn btn-outline-secondary mb-3">
        ← بازگشت
    </a>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="card shadow">
        <div class="card-body">

            <h3 class="fw-bold mb-3">{{ $survey->title }}</h3>
            <p class="fs-5 mb-4">{{ $survey->question }}</p>

            <form method="POST" action="{{ route('survey.vote',$survey->id) }}">
                @csrf

                @foreach($survey->options as $option)
                    <div class="form-check fs-5 mb-2">
                        <input class="form-check-input"
                               type="radio"
                               name="option"
                               value="{{ $option->id }}"
                               required>
                        <label class="form-check-label">
                            {{ $option->option_text }}
                            <span class="text-muted">
                                ( {{ $option->votes ?? 0 }} رأی )
                            </span>
                        </label>
                    </div>
                @endforeach

                <button class="btn btn-success mt-3">
                    ثبت رأی
                </button>

            </form>

        </div>
    </div>
</div>

</body>
</html>
