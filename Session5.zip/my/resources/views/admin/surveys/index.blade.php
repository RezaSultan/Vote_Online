@extends('layouts.app')

@section('content')
<div class="container mt-5">
  <h3>نظرسنجی‌های شما</h3>
  <a href="{{ route('admin.surveys.create') }}" class="btn btn-primary mb-3">ایجاد جدید</a>

  @if($surveys->count())
    <table class="table table-bordered">
      <thead><tr><th>عنوان</th><th>وضعیت</th><th>تاریخ</th></tr></thead>
      <tbody>
        @foreach($surveys as $s)
          <tr>
            <td>{{ $s->title }}</td>
            <td>{{ $s->status }}</td>
            <td>{{ $s->created_at->format('Y-m-d H:i') }}</td>
          </tr>
        @endforeach
      </tbody>
    </table>
  @else
    <p>هیچ نظرسنجی‌ای وجود ندارد.</p>
  @endif
</div>
@endsection
