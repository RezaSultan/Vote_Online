@extends('layouts.app')

@section('content')
<div class="container mt-5">

    <div class="d-flex justify-content-between">
        <h2>داشبورد مدیر</h2>

        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button class="btn btn-danger">خروج</button>
        </form>
    </div>

    <hr>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <a href="{{ route('admin.surveys.create') }}" class="btn btn-primary mb-3">
        ایجاد نظرسنجی جدید
    </a>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>عنوان</th>
            <th>سؤال</th>
            <th>گزینه‌ها</th>
        </tr>
        </thead>
        <tbody>

        @forelse($surveys as $survey)
        <tr>
            <td>{{ $survey->title }}</td>
            <td>{{ $survey->question }}</td>
            <td>
                @foreach($survey->options as $opt)
                    <div>- {{ $opt->option_text }}</div>
                @endforeach
            </td>
        </tr>
        @empty
            <tr>
                <td colspan="3" class="text-center">هیچ نظرسنجی وجود ندارد</td>
            </tr>
        @endforelse

        </tbody>
    </table>

</div>
@endsection
