@extends('admin.layout')

@section('content')
<div class="container mt-4">

    <h2 class="mb-3">➕ ایجاد نظرسنجی جدید</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('admin.polls.store') }}">
        @csrf

        <div class="mb-3">
            <label class="form-label">عنوان نظرسنجی</label>
            <input type="text" name="title" class="form-control" placeholder="مثال: رضایت از سیستم" required>
        </div>

        <div class="mb-3">
            <label class="form-label">سؤال نظرسنجی</label>
            <textarea name="question" class="form-control" rows="3" placeholder="مثال: آیا از عملکرد سیستم راضی هستید؟" required></textarea>
        </div>

        <label class="form-label">گزینه‌ها</label>
        <div id="options">
            <input type="text" name="options[]" class="form-control mb-2" placeholder="گزینه 1" required>
            <input type="text" name="options[]" class="form-control mb-2" placeholder="گزینه 2" required>
        </div>

        <button type="button" class="btn btn-secondary mb-3" onclick="addOption()">+ افزودن گزینه</button>

        <div>
            <button class="btn btn-success">ثبت نظرسنجی</button>
            <a href="{{ route('admin.polls.index') }}" class="btn btn-outline-dark">بازگشت</a>
        </div>
    </form>
</div>

<script>
    function addOption(){
        const input = document.createElement('input');
        input.type = 'text';
        input.name = 'options[]';
        input.className = 'form-control mb-2';
        input.placeholder = 'گزینه جدید';
        document.getElementById('options').appendChild(input);
    }
</script>
@endsection
