<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پلتفرم نظرسنجی پیشرو - نظرات خود را به دنیا نشان دهید</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap');
        
        * {
            font-family: 'Vazirmatn', sans-serif;
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #3B82F6 0%, #9333EA 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .card-hover {
            transition: all 0.3s ease;
        }
        
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #3B82F6 0%, #9333EA 100%);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(59, 130, 246, 0.3);
        }
        
        .stats-gradient {
            background: linear-gradient(135deg, #3B82F6 0%, #9333EA 100%);
        }
        
        .hero-bg {
            background: linear-gradient(135deg, #EBF8FF 0%, #FFFFFF 50%, #F3E8FF 100%);
        }
        
        .dark .hero-bg {
            background: linear-gradient(135deg, #1F2937 0%, #111827 50%, #581C87 100%);
        }
        
        .feature-icon {
            transition: all 0.3s ease;
        }
        
        .feature-card:hover .feature-icon {
            transform: scale(1.1);
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        .float-animation {
            animation: float 6s ease-in-out infinite;
        }
        
        .dark {
            color-scheme: dark;
        }
    </style>
</head>
<body class="hero-bg min-h-screen">
    <!-- Hero Section -->
    <section class="relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 dark:from-blue-400/10 dark:to-purple-400/10"></div>
        <div class="relative container mx-auto px-4 py-20 md:py-32">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div class="space-y-8">
                    <div class="space-y-4">
                        <span class="inline-flex items-center gap-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium">
                            <i class="fas fa-star text-yellow-500"></i>
                            پلتفرم نظرسنجی پیشرو
                        </span>
                        <h1 class="text-4xl md:text-6xl font-bold gradient-text">
                            نظرات خود را به دنیا نشان دهید
                        </h1>
                        <p class="text-lg md:text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
                            با پلتفرم نظرسنجی ما، به راحتی نظرسنجی‌های حرفه‌ای ایجاد کنید، 
                            نتایج را تحلیل نمایید و تصمیمات بهتری بگیرید. 
                            همراه با میلیون‌ها کاربر راضی در سراسر جهان.
                        </p>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row gap-4">
                       <a href="{{ route('login') }}" class="btn-primary text-white px-8 py-3 text-lg font-medium rounded-lg inline-flex items-center justify-center gap-2">
                            ورود به حساب کاربری
                            <i class="fas fa-arrow-left"></i>
                        </a>
                        <a href="{{ route('register') }}" class="bg-white dark:bg-gray-800 text-gray-800 dark:text-white px-8 py-3 text-lg font-medium rounded-lg inline-flex items-center justify-center gap-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all">
                            ثبت نام رایگان
                            <i class="fas fa-users"></i>
                        </a>
                    </div>

                    <div class="flex flex-wrap items-center gap-6 pt-4">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-check-circle text-green-500 text-xl"></i>
                            <span class="text-sm text-gray-600 dark:text-gray-300">شروع رایگان</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <i class="fas fa-shield-alt text-blue-500 text-xl"></i>
                            <span class="text-sm text-gray-600 dark:text-gray-300">امنیت بالا</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <i class="fas fa-bolt text-purple-500 text-xl"></i>
                            <span class="text-sm text-gray-600 dark:text-gray-300">سریع و آسان</span>
                        </div>
                    </div>
                </div>

                <div class="relative float-animation">
                    <div class="relative rounded-2xl overflow-hidden shadow-2xl">
                        <img 
                            src="https://fh1.linklick.ir/40ab6b53e57c0774b31bd95e810238da.linklick.ir.png"
                            alt="Survey Dashboard"
                            class="w-full h-auto"
                        />
                        <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-20 bg-white/50 dark:bg-gray-800/50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold mb-4 text-gray-800 dark:text-white">
                    چرا پلتفرم نظرسنجی ما را انتخاب کنید؟
                </h2>
                <p class="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                    با ابزارهای حرفه‌ای و رابط کاربری آسان، بهترین تجربه نظرسنجی را برای شما فراهم می‌کنیم
                </p>
            </div>

            <div class="grid md:grid-cols-3 gap-8">
                <div class="feature-card card-hover bg-white dark:bg-gray-800 rounded-xl p-8 text-center">
                    <div class="feature-icon w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-chart-bar text-2xl text-blue-600 dark:text-blue-400"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-3 text-gray-800 dark:text-white">تحلیل پیشرفته</h3>
                    <p class="text-gray-600 dark:text-gray-300 leading-relaxed">
                        با نمودارها و گزارش‌های تعاملی، نتایج نظرسنجی‌های خود را به صورت عمیق تحلیل کنید
                        و بینش‌های ارزشمندی کسب نمایید.
                    </p>
                </div>

                <div class="feature-card card-hover bg-white dark:bg-gray-800 rounded-xl p-8 text-center">
                    <div class="feature-icon w-16 h-16 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-users text-2xl text-purple-600 dark:text-purple-400"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-3 text-gray-800 dark:text-white">کاربران واقعی</h3>
                    <p class="text-gray-600 dark:text-gray-300 leading-relaxed">
                        به جامعه‌ای از میلیون‌ها کاربر واقعی دسترسی داشته باشید و نظرات معتبر و 
                        ارزشمندی برای محصولات و خدمات خود دریافت کنید.
                    </p>
                </div>

                <div class="feature-card card-hover bg-white dark:bg-gray-800 rounded-xl p-8 text-center">
                    <div class="feature-icon w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-bolt text-2xl text-green-600 dark:text-green-400"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-3 text-gray-800 dark:text-white">ساخت آسان</h3>
                    <p class="text-gray-600 dark:text-gray-300 leading-relaxed">
                        با چند کلیک ساده، نظرسنجی‌های حرفه‌ای ایجاد کنید و در کمترین زمان 
                        نظرات مخاطبان خود را جمع‌آوری نمایید.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-20 stats-gradient text-white">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div>
                    <div class="text-4xl md:text-5xl font-bold mb-2">2M+</div>
                    <div class="text-blue-100">کاربر فعال</div>
                </div>
                <div>
                    <div class="text-4xl md:text-5xl font-bold mb-2">500K+</div>
                    <div class="text-blue-100">نظرسنجی ایجاد شده</div>
                </div>
                <div>
                    <div class="text-4xl md:text-5xl font-bold mb-2">50M+</div>
                    <div class="text-blue-100">پاسخ ثبت شده</div>
                </div>
                <div>
                    <div class="text-4xl md:text-5xl font-bold mb-2">98%</div>
                    <div class="text-blue-100">رضایت کاربران</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20">
        <div class="container mx-auto px-4 text-center">
            <div class="max-w-3xl mx-auto">
                <h2 class="text-3xl md:text-4xl font-bold mb-4 text-gray-800 dark:text-white">
                    آماده شروع هستید؟
                </h2>
                <p class="text-lg text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
                    همین امروز به جامعه ما بپیوندید و اولین نظرسنجی خود را ایجاد کنید. 
                    ثبت نام کاملاً رایگان است و می‌توانید بلافاصله شروع به کار کنید.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="{{ route('register') }}" class="btn-primary text-white px-8 py-3 text-lg font-medium rounded-lg inline-flex items-center justify-center gap-2">
                        شروع رایگان
                        <i class="fas fa-arrow-left"></i>
                    </a>
                    <a href="#demo" class="bg-white dark:bg-gray-800 text-gray-800 dark:text-white px-8 py-3 text-lg font-medium rounded-lg inline-flex items-center justify-center gap-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all">
                        مشاهده دمو
                        <i class="fas fa-play"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-100 dark:bg-gray-900 py-12">
        <div class="container mx-auto px-4">
            <div class="text-center">
                <h3 class="text-2xl font-bold gradient-text mb-4">پلتفرم نظرسنجی پیشرو</h3>
                <p class="text-gray-600 dark:text-gray-300 mb-6">
                    بهترین پلتفرم برای ایجاد و تحلیل نظرسنجی‌های حرفه‌ای
                </p>
                <div class="flex justify-center gap-6 mb-6">
                    <a href="#" class="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                        <i class="fab fa-facebook text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                        <i class="fab fa-instagram text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                        <i class="fab fa-linkedin text-xl"></i>
                    </a>
                </div>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                    © 2024 پلتفرم نظرسنجی پیشرو. تمامی حقوق محفوظ است.
                </p>
            </div>
        </div>
    </footer>

    <!-- Dark Mode Toggle -->
    <button id="darkModeToggle" class="fixed top-4 left-4 bg-white dark:bg-gray-800 p-3 rounded-full shadow-lg z-50 transition-all">
        <i class="fas fa-moon text-gray-800 dark:text-yellow-400"></i>
    </button>

    <script>
        // Dark Mode Toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        const html = document.documentElement;
        
        // Check for saved dark mode preference
        if (localStorage.getItem('darkMode') === 'true') {
            html.classList.add('dark');
        }
        
        darkModeToggle.addEventListener('click', () => {
            html.classList.toggle('dark');
            localStorage.setItem('darkMode', html.classList.contains('dark'));
            
            // Update icon
            const icon = darkModeToggle.querySelector('i');
            if (html.classList.contains('dark')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
            }
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
        
        // Add scroll effect to navigation
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const hero = document.querySelector('.hero-bg');
            hero.style.transform = `translateY(${scrolled * 0.5}px)`;
        });
    </script>
</body>
</html>