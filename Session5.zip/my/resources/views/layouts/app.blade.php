<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>سامانه نظرسنجی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Vazirmatn, sans-serif; background:#f6f8fa; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="{{ url('/') }}">Survey System</a>
    <div class="collapse navbar-collapse">
    </div>
    <div class="d-flex">
        @auth
            <span class="navbar-text text-white me-3">{{ auth()->user()->name }}</span>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="btn btn-outline-light btn-sm">خروج</button>
            </form>
        @else
            <a href="{{ route('login') }}" class="btn btn-outline-light btn-sm me-2">ورود</a>
            <a href="{{ route('register') }}" class="btn btn-light btn-sm">ثبت‌نام</a>
        @endauth
    </div>
  </div>
</nav>

<main class="py-4">
    @yield('content')
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
