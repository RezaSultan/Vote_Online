<?php
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PublicSurveyController;
use App\Http\Controllers\Admin\SurveyController;


Route::get('/surveys', [PublicSurveyController::class, 'api']);

Route::post('/signup', [AuthController::class, 'signup']);
Route::post('/login', [AuthController::class, 'login']);

// Protected route (JWT required)
Route::middleware('auth:api')->get('/admin/dashboard', function () {
    return response()->json(['message' => 'Welcome, Admin!']);
});


Route::get('/surveys', [SurveyController::class, 'getSurveys']);
Route::get('/surveys/{id}', [SurveyController::class, 'show']);
Route::post('/vote', [SurveyController::class, 'vote']);
