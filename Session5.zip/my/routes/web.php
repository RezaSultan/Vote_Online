<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Admin\SurveyController;
use App\Http\Controllers\PublicSurveyController;
use App\Http\Controllers\UserDashboardController;

/*
| Web Routes
*/

// welcome or home
Route::get('/', function () {
    return view('welcome');
});

// auth
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

Route::get('/register', [LoginController::class, 'showRegister'])->name('register');
Route::post('/register', [LoginController::class, 'register'])->name('register.submit');

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// dashboard (decides admin or user)
Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth')->name('dashboard');

// admin survey routes (protected by admin middleware inside controller too)

Route::get('/admin/dashboard', [SurveyController::class, 'dashboard'])
    ->name('admin.dashboard')
    ->middleware('auth');

Route::prefix('admin')->middleware('auth')->group(function () {

    Route::get('/dashboard', [SurveyController::class, 'index'])->name('admin.dashboard');

    Route::get('/surveys/create', [SurveyController::class, 'create'])->name('admin.surveys.create');

    Route::post('/surveys/store', [SurveyController::class, 'store'])->name('admin.surveys.store');

});
Route::get('/surveys', [SurveyController::class, 'index']);


Route::post('/vote/{survey}', [PublicSurveyController::class, 'vote'])->name('vote.survey');


Route::get('/user/dashboard', [UserDashboardController::class, 'index'])
    ->name('user.dashboard')
    ->middleware('auth'); // اگر می‌خواهی فقط کاربران لاگین ببینند؛ حذفش کن اگر عمومی است
/* ========== PUBLIC ========== */


Route::get('/survey/{id}', [SurveyController::class, 'show'])->name('survey.show');

Route::post('/survey/vote', [SurveyController::class, 'vote'])->name('survey.vote');

Route::post('/vote/{survey}', [PublicSurveyController::class, 'vote'])->name('vote.survey');
