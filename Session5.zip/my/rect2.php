<?php
$tool = $_GET['tool'];
$arz = $_GET['arz'];
$masahat = $tool *$arz;
$mohit = 2*($tool*$arz);

echo "mass :  $masahat <br>";

echo"mohit: $mohit" ;
?>