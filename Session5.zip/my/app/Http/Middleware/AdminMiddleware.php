<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (Auth::check() && Auth::user()->role === 'admin') {
            return $next($request);
        }

        // redirect to dashboard or abort
        if ($request->wantsJson()) {
            return response()->json(['message'=>'Access denied'], 403);
        }
        return redirect('/dashboard')->with('error','دسترسی غیرمجاز');
    }
}
