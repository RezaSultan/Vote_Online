<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\Vote;
use Illuminate\Support\Facades\Auth;

class UserDashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $user = Auth::user();

        $totalSurveys  = Survey::count();
        $activeSurveys = Survey::where('is_active', 1)->count();
        $totalVotes    = Vote::count();

        // آخرین 5 نظرسنجی فعال با تعداد رأی
        $latestSurveys = Survey::where('is_active', 1)
            ->withCount('votes')
            ->latest()
            ->take(5)
            ->get();

        return view('user.dashboard', compact(
            'user',
            'totalSurveys',
            'activeSurveys',
            'totalVotes',
            'latestSurveys'
        ));
    }
}
