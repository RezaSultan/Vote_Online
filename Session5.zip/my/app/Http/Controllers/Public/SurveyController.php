<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Survey;
use App\Models\Option;
use App\Models\Vote;
use Illuminate\Support\Facades\DB;

class SurveyController extends Controller
{
    // صفحه لیست نظرسنجی برای کاربر
    public function index()
    {
        return view('public.surveys');
    }

    // API: گرفتن همه نظرسنجی‌های فعال
    public function getSurveys()
    {
        $surveys = Survey::where('is_active', 1)->get();
        return response()->json($surveys);
    }

    // API: گرفتن یک نظرسنجی + گزینه‌ها
    public function show($id)
    {
        $survey = Survey::with('options')->findOrFail($id);

        if($survey->is_active == 0){
            return response()->json(['message' => 'این نظرسنجی غیرفعال است'], 403);
        }

        return response()->json($survey);
    }

    // API: ثبت رأی - نسخه اصلاح شده و کامل
    public function vote(Request $request)
    {
        // اعتبارسنجی
        $validated = $request->validate([
            'survey_id' => 'required|exists:surveys,id',
            'option_id' => 'required|exists:options,id'
        ]);

        // شروع تراکنش
        DB::beginTransaction();

        try {
            // پیدا کردن نظرسنجی و گزینه
            $survey = Survey::findOrFail($request->survey_id);
            $option = Option::findOrFail($request->option_id);
            
            // بررسی فعال بودن نظرسنجی
            if (!$survey->is_active) {
                throw new \Exception('این نظرسنجی غیرفعال است');
            }
            
            // بررسی تطابق گزینه با نظرسنجی
            if ($option->survey_id != $survey->id) {
                throw new \Exception('گزینه انتخابی متعلق به این نظرسنجی نیست');
            }
            
            // بررسی رأی تکراری (بر اساس IP)
            $ipAddress = $request->ip();
            $alreadyVoted = Vote::where('survey_id', $survey->id)
                ->where('ip_address', $ipAddress)
                ->exists();
                
            if ($alreadyVoted) {
                throw new \Exception('شما قبلاً در این نظرسنجی رأی داده‌اید');
            }
            
            // ایجاد رکورد رأی
            $vote = Vote::create([
                'survey_id' => $survey->id,
                'option_id' => $option->id,
                'ip_address' => $ipAddress,
                'user_id' => auth()->id() // اگر کاربر لاگین کرده باشد
            ]);
            
            // افزایش تعداد رأی در گزینه (اگر فیلد votes وجود دارد)
            if (isset($option->votes)) {
                $option->increment('votes');
            }
            
            // اعمال تغییرات
            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'رأی شما با موفقیت ثبت شد ✅',
                'vote_id' => $vote->id
            ]);
            
        } catch (\Exception $e) {
            // بازگرداندن تغییرات در صورت خطا
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    
    // متد جایگزین اگر نمی‌خواهید فیلد votes را به options اضافه کنید
    public function voteAlternative(Request $request)
    {
        $validated = $request->validate([
            'survey_id' => 'required|exists:surveys,id',
            'option_id' => 'required|exists:options,id'
        ]);

        DB::beginTransaction();

        try {
            $survey = Survey::findOrFail($request->survey_id);
            $option = Option::findOrFail($request->option_id);
            
            if (!$survey->is_active) {
                throw new \Exception('این نظرسنجی غیرفعال است');
            }
            
            if ($option->survey_id != $survey->id) {
                throw new \Exception('گزینه انتخابی متعلق به این نظرسنجی نیست');
            }
            
            $ipAddress = $request->ip();
            $alreadyVoted = Vote::where('survey_id', $survey->id)
                ->where('ip_address', $ipAddress)
                ->exists();
                
            if ($alreadyVoted) {
                throw new \Exception('شما قبلاً در این نظرسنجی رأی داده‌اید');
            }
            
            // فقط ایجاد رکورد رأی (بدون افزایش votes در options)
            $vote = Vote::create([
                'survey_id' => $survey->id,
                'option_id' => $option->id,
                'ip_address' => $ipAddress,
                'user_id' => auth()->id()
            ]);
            
            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'رأی شما با موفقیت ثبت شد ✅'
            ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
}