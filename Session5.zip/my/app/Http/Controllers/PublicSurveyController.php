<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\Option;
use Illuminate\Http\Request;

class PublicSurveyController extends Controller
{
    // نمایش همه نظرسنجی‌های فعال
    public function index()
    {
        $surveys = Survey::where('is_active', 1)->get();
        return response()->json($surveys);
    }

    // نمایش یک نظرسنجی + گزینه‌ها
    public function show($id)
    {
        $survey = Survey::with('options')->findOrFail($id);

        if (!$survey->is_active) {
            return response()->json(['message' => 'Survey is not active'], 403);
        }

        return response()->json($survey);
    }

    // ثبت رأی
    public function vote(Request $request)
    {
        $request->validate([
            'option_id' => 'required|exists:options,id'
        ]);

        $option = Option::findOrFail($request->option_id);
        $option->increment('votes');

        return response()->json(['message' => 'Vote submitted successfully']);
    }
}
