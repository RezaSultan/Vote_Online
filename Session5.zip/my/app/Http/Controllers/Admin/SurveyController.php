<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Survey;
use App\Models\Option;
use App\Models\Vote;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SurveyController extends Controller
{
    public function index()
    {
        $surveys = Survey::where('admin_id', Auth::id())
            ->with('options')
            ->latest()
            ->get();

        return view('admin.dashboard', compact('surveys'));
    }

    public function create()
    {
        return view('admin.surveys.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'     => 'required',
            'question'  => 'required',
            'options'   => 'required|array|min:2'
        ]);

        $survey = Survey::create([
            'admin_id'  => Auth::id(),
            'title'     => $request->title,
            'question'  => $request->question,
            'is_active' => true,
        ]);

        foreach ($request->options as $opt) {
            if(!empty($opt)){
                Option::create([
                    'survey_id' => $survey->id,
                    'option_text' => $opt
                ]);
            }
        }

        return redirect()->route('admin.dashboard')
            ->with('success','نظرسنجی با موفقیت ساخته شد ✅');
    }


/* ---------------- PUBLIC LIST ---------------- */
public function publicList()
{
    $surveys = Survey::where('is_active',1)
        ->latest()
        ->get();

    return view('public', compact('surveys'));
}


/* -------- PAGE FOR SINGLE SURVEY -------- */
public function show($id)
{
    $survey = Survey::with('options')->findOrFail($id);

    return view('vote', compact('survey'));
}


/* ---------------- SUBMIT VOTE ---------------- */
public function vote(Request $request)
{
    $request->validate([
        'survey_id   ' => 'required',
        'option_id' => 'required'
    ]);

    $alreadyVoted = Vote::where('survey_id',$request->survey_id)
        ->where('ip_address', $request->ip())
        ->exists();

    if($alreadyVoted){
        return back()->with('error','You already voted on this survey');
    }

    Vote::create([
        'survey_id' => $request->survey_id,
        'option_id' => $request->option_id,
        'ip_address'   => $request->ip()
    ]);

    return redirect()->route('public.surveys')->with('success','Vote submitted successfully');
}

}
