<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Poll;
use App\Models\PollOption;
use Illuminate\Http\Request;

class PollController extends Controller
{
    public function index()
    {
        $polls = Poll::latest()->get();
        return view('admin.polls.index', compact('polls'));
    }

    public function create()
    {
        return view('admin.polls.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'question' => 'required',
            'options' => 'required|array|min:2'
        ]);

        $poll = Poll::create([
            'title' => $request->title,
            'question' => $request->question,
            'is_active' => true
        ]);

        foreach ($request->options as $option){
            if($option != ''){
                PollOption::create([
                    'poll_id' => $poll->id,
                    'option_text' => $option
                ]);
            }
        }

        return redirect()->route('admin.polls.index')
        ->with('success','نظرسنجی با موفقیت ثبت شد ✅');
    }
}
