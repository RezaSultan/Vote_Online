<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Survey;

class DashboardController extends Controller
{


    public function index()
    {
        $user = Auth::user();

        if ($user->role === 'admin') {
            $surveys = $user->surveys()->with('options')->orderByDesc('created_at')->get();
            return view('admin.dashboard', compact('user','surveys'));
        }

        $surveys = Survey::where('is_active',1)->with('options')->get();
        return view('user.dashboard', compact('user','surveys'));
    }
}
