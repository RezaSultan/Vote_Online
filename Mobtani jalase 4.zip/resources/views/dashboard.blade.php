<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد | سامانه نظرسنجی</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            font-family: 'Vazir', sans-serif;
            background-color: #f4f6f9;
        }
        .sidebar {
            height: 100vh;
            background-color: #343a40;
            color: #fff;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
            margin: 5px 0;
        }
        .sidebar a:hover {
            background-color: #495057;
            border-radius: 5px;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .navbar-custom {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .chart-container {
            width: 100%;
            height: 300px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <div class="col-md-2 sidebar p-0">
            <h3 class="text-center py-3">سامانه نظرسنجی</h3>
            <a href="#">داشبورد</a>
            <a href="#">نظرسنجی‌ها</a>
            <a href="#">ایجاد نظرسنجی</a>
            <a href="{{ url('/logout') }}">خروج</a>
        </div>

        <!-- Main Content -->
        <div class="col-md-10 p-4">

            <!-- Navbar -->
            <nav class="navbar navbar-expand navbar-custom mb-4">
                <div class="container-fluid">
                    <span class="navbar-brand mb-0 h1">خوش آمدی، {{ Auth::user()->name }}</span>
                    <span class="ms-auto">نقش: {{ Auth::user()->role }}</span>
                </div>
            </nav>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card p-3">
                        <h5>تعداد نظرسنجی‌ها</h5>
                        <h2>12</h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3">
                        <h5>تعداد کاربران</h5>
                        <h2>34</h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3">
                        <h5>کل آرا</h5>
                        <h2>256</h2>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card p-3 mb-4">
                        <h5>نمودار دایره‌ای نظرسنجی</h5>
                        <canvas id="pieChart" class="chart-container"></canvas>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-3 mb-4">
                        <h5>نمودار میله‌ای آرا</h5>
                        <canvas id="barChart" class="chart-container"></canvas>
                    </div>
                </div>
            </div>

            <!-- Recent Surveys Table -->
            <div class="card p-3">
                <h5>نظرسنجی‌های اخیر</h5>
                <table class="table table-striped mt-3">
                    <thead>
                        <tr>
                            <th>عنوان</th>
                            <th>وضعیت</th>
                            <th>تاریخ ایجاد</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>نظرسنجی نمونه 1</td>
                            <td>فعال</td>
                            <td>2025-11-07</td>
                            <td><button class="btn btn-sm btn-primary">ویرایش</button></td>
                        </tr>
                        <tr>
                            <td>نظرسنجی نمونه 2</td>
                            <td>غیرفعال</td>
                            <td>2025-11-05</td>
                            <td><button class="btn btn-sm btn-primary">ویرایش</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<!-- Chart.js Script -->
<script>
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    const pieChart = new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: ['گزینه 1', 'گزینه 2', 'گزینه 3'],
            datasets: [{
                label: 'آرا',
                data: [50, 30, 20],
                backgroundColor: ['#3498db','#2ecc71','#e74c3c']
            }]
        },
    });

    const barCtx = document.getElementById('barChart').getContext('2d');
    const barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: ['نظرسنجی 1', 'نظرسنجی 2', 'نظرسنجی 3'],
            datasets: [{
                label: 'تعداد آرا',
                data: [12, 19, 7],
                backgroundColor: '#3498db'
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

</body>
</html>
