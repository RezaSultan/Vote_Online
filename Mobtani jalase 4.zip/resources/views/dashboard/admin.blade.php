<!DOCTYPE html>
<html lang="fa">
<head>
  <meta charset="UTF-8">
  <title>داشبورد مدیر</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <span class="navbar-brand">مدیر سیستم</span>
    <a href="{{ route('logout') }}" class="btn btn-danger">خروج</a>
  </div>
</nav>

<div class="container mt-5">
  <h2>خوش آمدید، {{ $user->name }}</h2>
  <div class="card mt-4 p-4 shadow">
    <h5>مدیریت نظرسنجی‌ها</h5>
    <a href="#" class="btn btn-primary mt-3">ایجاد نظرسنجی جدید</a>
    <a href="#" class="btn btn-outline-secondary mt-3">مشاهده آمار</a>
  </div>
</div>
</body>
</html>
