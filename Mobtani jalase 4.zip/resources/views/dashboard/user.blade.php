<!DOCTYPE html>
<html lang="fa">
<head>
  <meta charset="UTF-8">
  <title>داشبورد کاربر</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <span class="navbar-brand">داشبورد کاربر</span>
    <a href="{{ route('logout') }}" class="btn btn-light">خروج</a>
  </div>
</nav>

<div class="container mt-5">
  <h3>سلام {{ $user->name }} 👋</h3>
  <div class="card p-4 shadow mt-3">
    <h5>نظرسنجی‌های فعال</h5>
    <ul class="list-group mt-3">
      <li class="list-group-item">بهترین زبان برنامه‌نویسی کدام است؟</li>
      <li class="list-group-item">از رابط کاربری سایت راضی هستید؟</li>
      <li class="list-group-item">پیشنهاد شما برای بهبود چیست؟</li>
    </ul>
  </div>
</div>
</body>
</html>
