<!DOCTYPE html>
<html>
<head>
    <title>Survey System</title>
    <style>
        body { font-family: sans-serif; background: #f8f9fa; text-align: center; }
        .container { width: 400px; margin: 50px auto; background: #fff; padding: 20px; border-radius: 10px; }
        input { width: 90%; padding: 10px; margin: 8px 0; }
        button { padding: 10px 20px; background: #3490dc; color: white; border: none; border-radius: 5px; }
    </style>
</head>
<body>
<div class="container">
    @yield('content')
</div>
</body>
</html>
