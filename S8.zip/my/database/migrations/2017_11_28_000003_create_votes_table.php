<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('votes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('survey_id')->constrained('surveys')->onDelete('cascade');
            $table->foreignId('option_id')->constrained('options')->onDelete('cascade');

            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('ip_address', 45)->nullable();

            $table->timestamps();

            // جلوگیری از رأی تکراری: هر کاربر فقط یک بار در هر survey
            $table->unique(['survey_id', 'user_id']);
            // جلوگیری از رأی تکراری: هر IP فقط یک بار در هر survey (برای مهمان‌ها)
            $table->unique(['survey_id', 'ip_address']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('votes');
    }
};
