<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>سامانه نظرسنجی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('survey.index')); ?>">نظرسنجی</a>

        <div class="ms-auto">
            <?php if(auth()->guard()->check()): ?>
                <span class="me-3">سلام، <?php echo e(Auth::user()->name); ?></span>
                <form class="d-inline" method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-outline-danger btn-sm">خروج</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary btn-sm me-2">ورود</a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-sm">ثبت نام</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<div class="container my-4">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\my\resources\views/layouts/app.blade.php ENDPATH**/ ?>