

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-8">

        <div class="card mb-3">
            <div class="card-header">
                <h4 class="mb-0"><?php echo e($survey->title); ?></h4>
            </div>

            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <p><?php echo e($survey->question); ?></p>

                <form action="<?php echo e(route('survey.vote', $survey->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <?php $__currentLoopData = $survey->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" id="opt<?php echo e($option->id); ?>" name="option_id" value="<?php echo e($option->id); ?>" required>
                            <label class="form-check-label" for="opt<?php echo e($option->id); ?>">
                                <?php echo e($option->option_text); ?>

                            </label>
                            <span class="text-muted ms-2"> (<?php echo e($option->votes_count ?? 0); ?> رأی)</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-3">
                        <button class="btn btn-success">ثبت رأی</button>
                    </div>
                </form>
            </div>
        </div>
<?php if(!$survey->is_active): ?>
    <div class="alert alert-warning text-center">
        این نظرسنجی بسته شده است و امکان رأی‌دادن وجود ندارد.
    </div>
<?php else: ?>
    
<?php endif; ?>

        <div class="card">
            <div class="card-header">
                نتایج فعلی
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $survey->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-2">
                        <strong><?php echo e($opt->option_text); ?></strong>
                        <div><?php echo e($opt->votes_count ?? 0); ?> رأی</div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my\resources\views/surveys/vote.blade.php ENDPATH**/ ?>