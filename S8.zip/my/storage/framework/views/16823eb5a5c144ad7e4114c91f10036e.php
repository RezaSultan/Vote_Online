

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4">ایجاد نظرسنجی جدید</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.surveys.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>عنوان نظرسنجی</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>سؤال</label>
            <textarea name="question" class="form-control" rows="3" required></textarea>
        </div>

        <label>گزینه‌ها:</label>
        <div id="option-box">
            <input type="text" name="options[]" class="form-control mb-2" placeholder="گزینه 1">
            <input type="text" name="options[]" class="form-control mb-2" placeholder="گزینه 2">
        </div>

        <button type="button" class="btn btn-secondary my-2" onclick="addOption()">افزودن گزینه</button>

        <button type="submit" class="btn btn-success">ذخیره نظرسنجی</button>

    </form>
</div>

<script>
    function addOption(){
        let input = document.createElement("input");
        input.type = "text";
        input.name = "options[]";
        input.className = "form-control mb-2";
        document.getElementById("option-box").appendChild(input);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\my\resources\views/admin/surveys/create.blade.php ENDPATH**/ ?>