<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use Illuminate\Http\Request;

class SurveyResultController extends Controller
{
    /* صفحه نتایج برای مدیر */
    public function admin(Survey $survey)
    {
        return view('admin.surveys.results', compact('survey'));
    }

    /* صفحه نتایج عمومی (فقط بسته شده) */
    public function public(Survey $survey)
    {
        if ($survey->is_active) {
            abort(403, 'این نظرسنجی هنوز فعال است');
        }

        return view('public.results', compact('survey'));
    }

    /* API داده‌های نمودار */
    public function api(Survey $survey)
    {
        $options = $survey->options()
            ->withCount('votes')
            ->get();

        $totalVotes = $options->sum('votes_count');

        $data = $options->map(function ($option) use ($totalVotes) {
            return [
                'label' => $option->title,
                'votes' => $option->votes_count,
                'percent' => $totalVotes > 0
                    ? round(($option->votes_count / $totalVotes) * 100, 1)
                    : 0
            ];
        });

        return response()->json([
            'total_votes' => $totalVotes,
            'data' => $data
        ]);
    }
}
