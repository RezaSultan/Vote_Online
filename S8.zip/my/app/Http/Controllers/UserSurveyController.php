<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Survey;
use App\Models\Vote;
use Illuminate\Support\Facades\Auth;

class UserSurveyController extends Controller
{
    // لیست نظرسنجی‌ها (عمومی)
    public function index()
    {
        $surveys = Survey::withCount('votes')
                         ->with('options')
                         ->where('is_active', true)
                         ->latest()
                         ->get();

        return view('surveys.index', compact('surveys'));
    }

    // نمایش صفحه رأی گیری
    public function show($id)
    {
        $survey = Survey::with(['options' => function($q){
            $q->withCount('votes');
        }])->findOrFail($id);

        return view('surveys.vote', compact('survey'));
    }

    // ثبت رأی
    public function vote(Request $request, $id)
    {
        $request->validate([
            'option_id' => 'required|exists:options,id'
        ]);

        $survey = Survey::findOrFail($id);
        $ip = $request->ip();
        $userId = Auth::check() ? Auth::id() : null;

        // بررسی رأی قبلی: اگر کاربر لاگین است با user_id، در غیر اینصورت با ip
        $alreadyVoted = Vote::where('survey_id', $survey->id)
            ->where(function ($q) use ($userId, $ip) {
                if ($userId) {
                    $q->where('user_id', $userId);
                } else {
                    $q->where('ip_address', $ip);
                }
            })->exists();

        if ($alreadyVoted) {
            return redirect()->route('survey.show', $survey->id)
                ->with('error', 'شما قبلاً در این نظرسنجی رأی داده‌اید.');
        }

        Vote::create([
            'survey_id' => $survey->id,
            'option_id' => $request->option_id,
            'user_id'   => $userId,
            'ip_address'=> $ip
        ]);

        return redirect()->route('survey.show', $survey->id)
            ->with('success', 'مرسی! رأی شما ثبت شد.');
    }


    
}
