<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Survey;
use App\Models\Option;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SurveyController extends Controller
{
    public function index()
    {
        $surveys = Survey::where('admin_id', Auth::id())
            ->with('options')
            ->latest()
            ->get();

        return view('admin.dashboard', compact('surveys'));
    }

    public function create()
    {
        return view('admin.surveys.create');
    }
public function toggleStatus(Survey $survey)
{
    $survey->update([
        'is_active' => !$survey->is_active
    ]);

    return back()->with('success', 'وضعیت نظرسنجی با موفقیت تغییر کرد');
}

    public function store(Request $request)
    {
        $request->validate([
            'title'     => 'required',
            'question'  => 'required',
            'options'   => 'required|array|min:2'
        ]);

        $survey = Survey::create([
            'admin_id'  => Auth::id(),
            'title'     => $request->title,
            'question'  => $request->question,
            'is_active' => true,
        ]);

        foreach ($request->options as $opt) {
            if(!empty($opt)){
                Option::create([
                    'survey_id' => $survey->id,
                    'option_text' => $opt
                ]);
            }
        }

        return redirect()->route('admin.dashboard')
            ->with('success','نظرسنجی با موفقیت ساخته شد ✅');
    }
}
