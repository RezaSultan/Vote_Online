<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\Vote;
use Illuminate\Http\Request;

class PublicSurveyController extends Controller
{
    // لیست تمام نظرسنجی های فعال
    public function index()
    {
        $surveys = Survey::where('is_active', 1)
            ->with('options')
            ->latest()
            ->get();

        return view('public.surveys', compact('surveys'));
    }

    // ذخیره رأی
    public function vote(Request $request, Survey $survey)
    {
        $request->validate([
            'option_id' => 'required|exists:options,id'
        ]);

        Vote::create([
            'survey_id' => $survey->id,
            'option_id' => $request->option_id,
            'ip_address' => $request->ip()
        ]);

        return back()->with('success', '✅ رأی شما با موفقیت ثبت شد');
    }
}
