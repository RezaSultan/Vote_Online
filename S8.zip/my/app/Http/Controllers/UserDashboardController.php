<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\Vote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserDashboardController extends Controller
{
  

    public function index()
    {
        $surveys = Survey::withCount('votes')
            ->orderByDesc('created_at')
            ->get();

        return view('user.dashboard', [
            'surveys' => $surveys,
            'totalSurveys' => Survey::count(),
            'totalVotes' => Vote::count(),
            'user' => Auth::user(),
        ]);
    }
}
