<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Survey;
use App\Models\Option;
use Illuminate\Support\Facades\Auth;
use DB;

class SurveyController extends Controller
{


    public function index()
    {
        $surveys = Auth::user()->surveys()->withCount('votes')->with('options')->orderByDesc('created_at')->get();
        return view('admin.surveys.index', compact('surveys'));
    }

    public function create()
    {
        return view('admin.surveys.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'=>'required|string|max:255',
            'question'=>'required|string',
            'options'=>'required|array|min:2|max:10',
            'options.*'=>'required|string|max:255'
        ]);

        DB::transaction(function() use($request) {
            $survey = Survey::create([
                'title'=>$request->title,
                'question'=>$request->question,
                'status'=>'active',
                'admin_id'=>Auth::id(),
            ]);

            foreach($request->options as $opt) {
                Option::create([
                    'survey_id'=>$survey->id,
                    'option_text'=>$opt,
                ]);
            }
        });

        return redirect()->route('admin.surveys.index')->with('success','نظرسنجی ایجاد شد.');
    }
    public function dashboard()
{
    $surveys = Survey::with(['options.votes'])
                ->where('admin_id', auth()->id())
                ->latest()
                ->get();

    return view('admin.dashboard', compact('surveys'));
}

}
