<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role'
    ];

    protected $hidden = [
        'password',
    ];

    public function surveys()
    {
        return $this->hasMany(Survey::class, 'admin_id');
    }

    public function votes()
    {
        return $this->hasMany(Vote::class);
    }
}
