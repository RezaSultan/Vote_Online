<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Admin\SurveyController;
use App\Http\Controllers\PublicSurveyController;
use App\Http\Controllers\UserSurveyController;
use App\Http\Controllers\SurveyResultController;
use App\Http\Controllers\UserDashboardController;

/*
| Web Routes
*/

// welcome or home
Route::get('/', function () {
    return view('welcome'); });

// auth
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

Route::get('/register', [LoginController::class, 'showRegister'])->name('register');
Route::post('/register', [LoginController::class, 'register'])->name('register.submit');

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// dashboard (decides admin or user)
Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth')->name('dashboard');

// admin survey routes (protected by admin middleware inside controller too)

Route::get('/admin/dashboard', [SurveyController::class, 'dashboard'])
    ->name('admin.dashboard')
    ->middleware('auth');




Route::prefix('admin')->middleware('auth')->group(function(){

    Route::get('/dashboard', [SurveyController::class,'index'])->name('admin.dashboard');

    Route::get('/surveys/create', [SurveyController::class,'create'])->name('admin.surveys.create');

    Route::post('/surveys/store', [SurveyController::class,'store'])->name('admin.surveys.store');

});


Route::get('/surveys', [UserSurveyController::class, 'index'])->name('survey.index');
Route::get('/survey/{id}', [UserSurveyController::class, 'show'])->name('survey.show');
Route::post('/survey/{id}/vote', [UserSurveyController::class, 'vote'])->name('survey.vote');
/* نتایج برای مدیر */
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/surveys/{survey}/results', [SurveyResultController::class, 'admin'])
        ->name('admin.survey.results');
});

/* نتایج عمومی (فقط نظرسنجی بسته) */
Route::get('/surveys/{survey}/results', [SurveyResultController::class, 'public'])
    ->name('survey.results');

/* API داده‌های نمودار */
Route::get('/api/surveys/{survey}/results', [SurveyResultController::class, 'api'])
    ->name('survey.results.api');

    Route::middleware(['auth'])->prefix('admin')->group(function () {

    Route::post(
        '/surveys/{survey}/toggle-status',
        [App\Http\Controllers\Admin\SurveyController::class, 'toggleStatus']
    )->name('admin.surveys.toggle');

});


Route::get('/surveys/{survey}/results', [SurveyResultController::class, 'public'])
    ->name('survey.results.public');