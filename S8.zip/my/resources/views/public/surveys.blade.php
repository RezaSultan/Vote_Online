@extends('layouts.app')

@section('content')
<div class="container mt-5">

    <h2 class="text-center mb-4">نظرسنجی‌های فعال</h2>

    @if(session('success'))
        <div class="alert alert-success text-center">
            {{ session('success') }}
        </div>
    @endif

    @if($surveys->count() == 0)
        <div class="alert alert-warning text-center">
            فعلاً هیچ نظرسنجی فعالی وجود ندارد
        </div>
    @endif

    @foreach($surveys as $survey)
        <div class="card mb-4">
            <div class="card-body">

                <h5>{{ $survey->title }}</h5>
                <p>{{ $survey->question }}</p>

                <form method="POST" action="{{ route('vote.survey', $survey->id) }}">
                    @csrf

                    @foreach($survey->options as $option)
                        <div class="form-check">
                            <input class="form-check-input"
                                   type="radio"
                                   name="option_id"
                                   id="opt{{ $option->id }}"
                                   value="{{ $option->id }}"
                                   required>
                            <label class="form-check-label" for="opt{{ $option->id }}">
                                {{ $option->option_text }}
                            </label>
                        </div>
                    @endforeach

                    <button class="btn btn-primary mt-3">
                        ثبت رأی
                    </button>
                </form>

            </div>
        </div>
    @endforeach
</div>
@endsection
