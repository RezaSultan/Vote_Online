<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نتایج نظرسنجی | {{ $survey->title }}</title>
    
    <!-- CSS Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Vazirmatn', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .results-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            max-width: 1200px;
            width: 100%;
            animation: slideUp 0.6s ease-out;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .survey-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .survey-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .survey-header .question {
            font-size: 18px;
            opacity: 0.9;
            margin-bottom: 15px;
        }
        
        .stats-bar {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .stat-item {
            text-align: center;
            background: rgba(255,255,255,0.1);
            padding: 15px 25px;
            border-radius: 12px;
            backdrop-filter: blur(10px);
            min-width: 150px;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .results-body {
            padding: 40px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        
        @media (max-width: 992px) {
            .results-body {
                grid-template-columns: 1fr;
            }
        }
        
        .chart-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .chart-section h3 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
            font-size: 20px;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        .results-list {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            overflow-y: auto;
            max-height: 400px;
        }
        
        .result-item {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-right: 4px solid #667eea;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .result-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .result-item.winner {
            border-right-color: #28a745;
            background: linear-gradient(135deg, rgba(40, 167, 69, 0.05), transparent);
        }
        
        .result-item .option-text {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        
        .progress-container {
            background: #e9ecef;
            border-radius: 10px;
            height: 10px;
            margin: 10px 0;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 10px;
            transition: width 1s ease-out;
            position: relative;
        }
        
        .progress-bar.winner {
            background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .stats-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
            font-size: 14px;
        }
        
        .votes-count {
            font-weight: 700;
            color: #333;
        }
        
        .percentage {
            background: #667eea;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: 600;
            min-width: 70px;
            text-align: center;
        }
        
        .percentage.winner {
            background: #28a745;
        }
        
        .winner-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: #28a745;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            padding: 25px;
            background: #f8f9fa;
            border-top: 1px solid #e9ecef;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .btn-secondary:hover {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
        }
        
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255,255,255,0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            flex-direction: column;
            gap: 20px;
        }
        
        .spinner {
            width: 60px;
            height: 60px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .last-updated {
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
            font-size: 14px;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
    </style>
</head>
<body>

<div class="loading-overlay" id="loadingOverlay">
    <div class="spinner"></div>
    <h4>در حال بارگذاری نتایج...</h4>
</div>

<div class="results-container" style="display: none;" id="resultsContainer">
    
    <!-- Header -->
    <div class="survey-header">
        <h1>{{ $survey->title }}</h1>
        <div class="question">{{ $survey->question }}</div>
        
        <div class="stats-bar">
            <div class="stat-item">
                <div class="stat-value" id="totalVotes">0</div>
                <div class="stat-label">کل رأی‌ها</div>
            </div>
            <div class="stat-item">
                <div class="stat-value" id="totalOptions">0</div>
                <div class="stat-label">تعداد گزینه‌ها</div>
            </div>
            <div class="stat-item">
                <div class="stat-value" id="participationRate">0%</div>
                <div class="stat-label">نرخ مشارکت</div>
            </div>
        </div>
    </div>
    
    <!-- Results Body -->
    <div class="results-body">
        <!-- Chart Section -->
        <div class="chart-section">
            <h3><i class="fas fa-chart-pie me-2"></i>نمودار نتایج</h3>
            <div class="chart-container">
                <canvas id="publicChart"></canvas>
            </div>
        </div>
        
        <!-- Results List -->
        <div class="results-list">
            <h3><i class="fas fa-list-ol me-2"></i>جزئیات رأی‌ها</h3>
            <div id="resultsList">
                <!-- Results will be loaded here -->
            </div>
        </div>
    </div>
    
    <!-- Action Buttons -->
    <div class="action-buttons">
        <a href="{{ url()->previous() }}" class="btn btn-secondary">
            <i class="fas fa-arrow-right me-2"></i>
            بازگشت
        </a>
        <button onclick="shareResults()" class="btn btn-primary">
            <i class="fas fa-share-alt me-2"></i>
            اشتراک‌گذاری نتایج
        </button>
        <button onclick="printResults()" class="btn btn-primary">
            <i class="fas fa-print me-2"></i>
            چاپ نتایج
        </button>
    </div>
    
    <!-- Last Updated -->
    <div class="last-updated">
        <i class="fas fa-clock me-2"></i>
        آخرین به‌روزرسانی: <span id="lastUpdated">...</span>
    </div>
</div>

<script>
// Global variables
let chartInstance = null;
let resultsData = null;

// Fetch results on page load
fetch("{{ route('survey.results.api', $survey->id) }}")
.then(res => res.json())
.then(result => {
    resultsData = result.data;
    
    // Hide loading, show results
    document.getElementById('loadingOverlay').style.display = 'none';
    document.getElementById('resultsContainer').style.display = 'block';
    
    // Update stats
    updateStats(resultsData);
    
    // Create chart
    createChart(resultsData);
    
    // Create results list
    createResultsList(resultsData);
    
    // Set last updated time
    document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString('fa-IR');
    
    // Start auto-refresh every 30 seconds if survey is active
    if ({{ $survey->is_active ? 'true' : 'false' }}) {
        setInterval(refreshResults, 30000);
    }
})
.catch(error => {
    console.error('Error loading results:', error);
    document.getElementById('loadingOverlay').innerHTML = `
        <div style="text-align: center; color: #dc3545;">
            <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
            <h4>خطا در بارگذاری نتایج</h4>
            <p class="mt-2">متأسفانه نتایج قابل بارگذاری نیست</p>
            <button onclick="window.location.reload()" class="btn btn-primary mt-3">
                تلاش مجدد
            </button>
        </div>
    `;
});

function updateStats(data) {
    const totalVotes = data.reduce((sum, item) => sum + item.votes, 0);
    const maxVotes = Math.max(...data.map(item => item.votes));
    
    document.getElementById('totalVotes').textContent = totalVotes.toLocaleString();
    document.getElementById('totalOptions').textContent = data.length;
    
    // Calculate participation rate (mock for demo - you can adjust this)
    const participationRate = Math.min(Math.floor((totalVotes / (data.length * 50)) * 100), 100);
    document.getElementById('participationRate').textContent = `${participationRate}%`;
}

function createChart(data) {
    const ctx = document.getElementById('publicChart').getContext('2d');
    
    // Prepare data for chart
    const labels = data.map(item => item.label);
    const votes = data.map(item => item.votes);
    const percentages = data.map(item => item.percent);
    
    // Generate colors
    const backgroundColors = generateColors(data.length);
    const borderColors = backgroundColors.map(color => color.replace('0.8', '1'));
    
    // Destroy previous chart if exists
    if (chartInstance) {
        chartInstance.destroy();
    }
    
    chartInstance = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels.map((label, index) => `${label} (${percentages[index]}%)`),
            datasets: [{
                data: votes,
                backgroundColor: backgroundColors,
                borderColor: borderColors,
                borderWidth: 2,
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'left',
                    rtl: true,
                    labels: {
                        padding: 20,
                        font: {
                            size: 14,
                            family: 'Vazirmatn, sans-serif'
                        },
                        color: '#333'
                    }
                },
                tooltip: {
                    rtl: true,
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const percentage = context.parsed ? 
                                ((context.parsed / context.dataset.data.reduce((a, b) => a + b, 0)) * 100).toFixed(1) : 0;
                            return `${label}: ${value.toLocaleString()} رأی (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });
}

function createResultsList(data) {
    const resultsList = document.getElementById('resultsList');
    const totalVotes = data.reduce((sum, item) => sum + item.votes, 0);
    const maxVotes = Math.max(...data.map(item => item.votes));
    
    let html = '';
    
    data.forEach((item, index) => {
        const isWinner = item.votes === maxVotes && item.votes > 0;
        const percentage = totalVotes > 0 ? (item.votes / totalVotes * 100).toFixed(1) : 0;
        const percentageFormatted = parseFloat(percentage);
        
        html += `
            <div class="result-item ${isWinner ? 'winner' : ''}">
                ${isWinner ? '<span class="winner-badge"><i class="fas fa-crown me-1"></i>پیشتاز</span>' : ''}
                
                <div class="option-text">
                    ${index + 1}. ${item.label}
                </div>
                
                <div class="progress-container">
                    <div class="progress-bar ${isWinner ? 'winner' : ''}" 
                         style="width: ${percentage}%"
                         data-percentage="${percentage}">
                    </div>
                </div>
                
                <div class="stats-details">
                    <div class="votes-count">
                        <i class="fas fa-vote-yea me-1"></i>
                        ${item.votes.toLocaleString()} رأی
                    </div>
                    <div class="percentage ${isWinner ? 'winner' : ''}">
                        ${percentageFormatted}%
                    </div>
                </div>
            </div>
        `;
    });
    
    if (data.length === 0) {
        html = `
            <div class="empty-state">
                <i class="fas fa-chart-bar"></i>
                <h5>هنوز رأی‌ای ثبت نشده است</h5>
                <p>اولین نفری باشید که رأی می‌دهد!</p>
            </div>
        `;
    }
    
    resultsList.innerHTML = html;
    
    // Animate progress bars
    setTimeout(() => {
        document.querySelectorAll('.progress-bar').forEach(bar => {
            const percentage = bar.getAttribute('data-percentage');
            bar.style.width = percentage + '%';
        });
    }, 100);
}

function generateColors(count) {
    const colors = [
        'rgba(102, 126, 234, 0.8)',
        'rgba(40, 167, 69, 0.8)',
        'rgba(220, 53, 69, 0.8)',
        'rgba(255, 193, 7, 0.8)',
        'rgba(23, 162, 184, 0.8)',
        'rgba(111, 66, 193, 0.8)',
        'rgba(253, 126, 20, 0.8)',
        'rgba(32, 201, 151, 0.8)',
        'rgba(108, 117, 125, 0.8)',
        'rgba(0, 123, 255, 0.8)'
    ];
    
    // If we need more colors than available, generate random ones
    if (count > colors.length) {
        for (let i = colors.length; i < count; i++) {
            colors.push(`rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.8)`);
        }
    }
    
    return colors.slice(0, count);
}

function refreshResults() {
    fetch("{{ route('survey.results.api', $survey->id) }}")
    .then(res => res.json())
    .then(result => {
        resultsData = result.data;
        updateStats(resultsData);
        createChart(resultsData);
        createResultsList(resultsData);
        
        // Update last updated time
        document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString('fa-IR');
        
        // Show refresh notification
        showNotification('نتایج به‌روز شد', 'success');
    });
}

function shareResults() {
    const surveyTitle = "{{ $survey->title }}";
    const url = window.location.href;
    
    if (navigator.share) {
        navigator.share({
            title: `نتایج نظرسنجی: ${surveyTitle}`,
            text: `نظرسنجی "${surveyTitle}" را مشاهده کنید`,
            url: url
        });
    } else {
        // Fallback: Copy to clipboard
        navigator.clipboard.writeText(`نتایج نظرسنجی "${surveyTitle}"\n${url}`)
            .then(() => showNotification('لینک نتایج در کلیپ‌بورد کپی شد', 'success'))
            .catch(() => alert(`لینک نتایج:\n${url}`));
    }
}

function printResults() {
    const printContent = document.getElementById('resultsContainer').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = printContent;
    window.print();
    document.body.innerHTML = originalContent;
    window.location.reload();
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        left: 20px;
        right: 20px;
        background: ${type === 'success' ? '#28a745' : '#007bff'};
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 9999;
        text-align: center;
        animation: slideDown 0.3s ease-out;
    `;
    
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideUp 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}
</script>

</body>
</html>