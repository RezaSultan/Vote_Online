<!DOCTYPE html>
<html>
<head>
    <title>نظرسنجی‌ها</title>
    <meta charset="UTF-8">
</head>
<body style="font-family:tahoma;direction:rtl;padding:30px">

<h2>✅ لیست نظرسنجی های فعال</h2>

@if(session('success'))
    <p style="color:green">{{ session('success') }}</p>
@endif

@forelse($surveys as $survey)

    <div style="border:1px solid #ccc; padding:15px; margin:15px 0; border-radius:5px;">
        <h3>{{ $survey->title }}</h3>
        <p>{{ $survey->question }}</p>

        <form method="POST" action="/surveys/vote/{{ $survey->id }}">
            @csrf

            <label>
                <input type="radio" name="answer" value="1"> {{ $survey->option1 }}
            </label><br>

            <label>
                <input type="radio" name="answer" value="2"> {{ $survey->option2 }}
            </label><br>

            @if($survey->option3)
                <label>
                    <input type="radio" name="answer" value="3"> {{ $survey->option3 }}
                </label><br>
            @endif

            @if($survey->option4)
                <label>
                    <input type="radio" name="answer" value="4"> {{ $survey->option4 }}
                </label><br>
            @endif

            <button type="submit" style="margin-top:10px">ثبت رأی</button>
        </form>
    </div>

@empty
    <p>نظرسنجی فعالی وجود ندارد</p>
@endforelse

</body>
</html>
