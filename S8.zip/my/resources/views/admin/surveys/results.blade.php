<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نتایج نظرسنجی</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<div class="container py-5">

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">
                نتایج نظرسنجی:
                <strong>{{ $survey->title }}</strong>
            </h5>
        </div>

        <div class="card-body text-center">
            <p class="mb-4">{{ $survey->question }}</p>

            <canvas id="resultChart" height="120"></canvas>

            <hr>

            <p class="text-muted mt-3">
                مجموع آرا:
                <span id="totalVotes">0</span>
            </p>

            <a href="{{ url()->previous() }}" class="btn btn-secondary mt-3">
                بازگشت
            </a>
        </div>
    </div>

</div>

<script>
fetch("{{ route('survey.results.api', $survey->id) }}")
    .then(res => res.json())
    .then(result => {

        document.getElementById('totalVotes').innerText = result.total_votes;

        const labels = result.data.map(i => i.label + ' (' + i.percent + '%)');
        const votes  = result.data.map(i => i.votes);

        new Chart(document.getElementById('resultChart'), {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: votes
                }]
            },
            options: {
                responsive: true
            }
        });
    });
</script>

</body>
</html>
