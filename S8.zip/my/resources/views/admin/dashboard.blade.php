@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <!-- هدر داشبورد -->
    <div class="dashboard-header bg-white p-4 rounded-3 shadow-sm mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1 text-primary">داشبورد مدیریت نظرسنجی‌ها</h1>
                <p class="text-muted mb-0">ایجاد و مدیریت نظرسنجی‌ها و مشاهده نتایج</p>
            </div>
            
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button class="btn btn-outline-danger d-flex align-items-center">
                    <i class="bi bi-box-arrow-right ms-2"></i>
                    خروج از سیستم
                </button>
            </form>
        </div>
    </div>

    <!-- پیام موفقیت -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- بخش ایجاد نظرسنجی جدید -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title mb-1">نظرسنجی‌ها</h5>
                    <p class="text-muted small mb-0">تعداد: {{ $surveys->count() }} نظرسنجی</p>
                </div>
                <a href="{{ route('admin.surveys.create') }}" class="btn btn-primary d-flex align-items-center">
                    <i class="bi bi-plus-circle me-2"></i>
                    ایجاد نظرسنجی جدید
                </a>
            </div>
        </div>
    </div>

    <!-- لیست نظرسنجی‌ها -->
    @if($surveys->count() > 0)
        <div class="row">
            @foreach($surveys as $survey)
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm hover-shadow">
                        <div class="card-body">
                            <!-- وضعیت فعال/غیرفعال -->
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title text-primary mb-0">
                                    <i class="bi bi-clipboard-check me-2"></i>
                                    {{ $survey->title }}
                                </h5>
                                <span class="badge {{ $survey->is_active ? 'bg-success' : 'bg-secondary' }}">
                                    {{ $survey->is_active ? 'فعال' : 'غیرفعال' }}
                                </span>
                            </div>
                            
                            <!-- سوال نظرسنجی -->
                            <div class="mb-3">
                                <h6 class="text-muted small mb-2">سوال نظرسنجی:</h6>
                                <p class="card-text">{{ $survey->question }}</p>
                            </div>
                            
                            <!-- گزینه‌ها -->
                            <div class="mb-4">
                                <h6 class="text-muted small mb-2">گزینه‌ها:</h6>
                                <ul class="list-unstyled mb-0">
                                    @foreach($survey->options as $opt)
                                        <li class="mb-1">
                                            <span class="badge bg-light text-dark me-2">{{ $loop->iteration }}</span>
                                            {{ $opt->option_text }}
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                            
                            <!-- دکمه‌های عملیاتی -->
                            <div class="d-flex gap-2 mt-4">
                                <!-- دکمه مشاهده نتایج -->
                                <a href="{{ route('admin.survey.results', $survey->id) }}" 
                                   class="btn btn-info btn-sm flex-fill d-flex align-items-center justify-content-center">
                                    <i class="bi bi-bar-chart me-2"></i>
                                    مشاهده نتایج
                                </a>
                                
                                <!-- دکمه فعال/غیرفعال کردن نظرسنجی -->
                                <form action="{{ route('admin.surveys.toggle', $survey->id) }}"
                                      method="POST"
                                      class="flex-fill">
                                    @csrf
                                    <button class="btn btn-sm w-100 d-flex align-items-center justify-content-center
                                        {{ $survey->is_active ? 'btn-outline-danger' : 'btn-outline-success' }}"
                                        title="{{ $survey->is_active ? 'غیرفعال کردن نظرسنجی' : 'فعال کردن نظرسنجی' }}"
                                        onclick="return confirm('آیا مطمئن هستید؟')">
                                        <i class="bi {{ $survey->is_active ? 'bi-pause-circle' : 'bi-play-circle' }} me-2"></i>
                                        {{ $survey->is_active ? 'بستن' : 'باز کردن' }}
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent border-top-0 pt-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="bi bi-calendar3 me-1"></i>
                                    {{ $survey->created_at->format('Y/m/d') }}
                                </small>
                                <small class="text-muted">
                                    <i class="bi bi-list-ol me-1"></i>
                                    {{ $survey->options->count() }} گزینه
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <!-- حالت خالی -->
        <div class="card border-dashed border-2">
            <div class="card-body text-center py-5">
                <div class="mb-3">
                    <i class="bi bi-clipboard text-muted" style="font-size: 3rem;"></i>
                </div>
                <h5 class="text-muted mb-3">هنوز نظرسنجی‌ای ایجاد نکرده‌اید</h5>
                <p class="text-muted mb-4">با ایجاد اولین نظرسنجی، می‌توانید بازخورد کاربران را جمع‌آوری کنید</p>
                <a href="{{ route('admin.surveys.create') }}" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-2"></i>
                    ایجاد اولین نظرسنجی
                </a>
            </div>
        </div>
    @endif

</div>

<!-- استایل‌های اضافی -->
<style>
    .hover-shadow {
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .hover-shadow:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }
    .border-dashed {
        border-style: dashed !important;
    }
    .btn-outline-danger:hover {
        background-color: #dc3545;
        color: white;
    }
    .btn-outline-success:hover {
        background-color: #198754;
        color: white;
    }
    .badge {
        font-size: 0.75rem;
        padding: 0.35em 0.65em;
    }
</style>

<!-- آیکون‌های Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">

@endsection