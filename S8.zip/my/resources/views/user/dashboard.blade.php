<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>داشبورد کاربر</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: #f1f3f6;
            font-family: Vazirmatn, sans-serif;
        }

        .card-box {
            background: #fff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,.05);
            transition: transform 0.3s ease;
        }

        .card-box:hover {
            transform: translateY(-2px);
        }

        .survey-item {
            border-radius: 12px;
            padding: 15px;
            background: #fff;
            margin-bottom: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,.05);
            border-right: 4px solid #667eea;
            transition: all 0.3s ease;
        }

        .survey-item.closed {
            border-right-color: #dc3545;
            background: linear-gradient(to left, rgba(220, 53, 69, 0.03), transparent);
        }

        .survey-item:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,.1);
        }

        .btn-vote {
            background: linear-gradient(135deg,#667eea,#764ba2);
            color: white;
            border-radius: 8px;
            padding: 8px 20px;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-vote:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-vote:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .badge-active {
            background: linear-gradient(135deg,#28a745,#20c997);
            padding: 5px 12px;
            border-radius: 20px;
            color: white;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-closed {
            background: linear-gradient(135deg,#dc3545,#ff6b6b);
            padding: 5px 12px;
            border-radius: 20px;
            color: white;
            font-size: 12px;
            font-weight: 600;
        }

        .stats-card {
            position: relative;
            overflow: hidden;
            border: none;
        }

        .stats-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(135deg,#667eea,#764ba2);
        }

        .stats-card:nth-child(2)::before {
            background: linear-gradient(135deg,#28a745,#20c997);
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg,#667eea,#764ba2);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
            box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
        }

        /* نتایج سریع */
        .simple-results {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            border: 1px solid #e9ecef;
        }

        .simple-results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .simple-results-header h6 {
            margin: 0;
            color: #333;
        }

        .option-result {
            margin-bottom: 12px;
            padding: 10px;
            background: white;
            border-radius: 8px;
            border-left: 3px solid #667eea;
        }

        .option-result.winner {
            border-left-color: #28a745;
            background: linear-gradient(to right, rgba(40, 167, 69, 0.05), white);
        }

        .option-result .option-text {
            font-weight: 500;
            margin-bottom: 5px;
            color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .option-result .votes-count {
            color: #6c757d;
            font-size: 13px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 5px;
        }

        .vote-progress {
            height: 6px;
            background: #e9ecef;
            border-radius: 3px;
            margin-top: 5px;
            overflow: hidden;
        }

        .vote-progress-bar {
            height: 100%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 3px;
            transition: width 1s ease-out;
        }

        .vote-progress-bar.winner {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        /* دکمه‌ها */
        .survey-actions {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .results-btn {
            background: linear-gradient(135deg, #17a2b8, #20c997);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .results-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(23, 162, 184, 0.3);
            color: white;
        }

        .closed-message {
            background: linear-gradient(135deg, rgba(220, 53, 69, 0.1), transparent);
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid rgba(220, 53, 69, 0.2);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #dc3545;
            font-size: 13px;
        }

        .closed-message i {
            font-size: 16px;
        }

        /* برنده */
        .winner-badge {
            background: #28a745;
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 600;
            margin-right: 8px;
        }

        /* فیلترها */
        .filter-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .filter-btn {
            padding: 6px 20px;
            border-radius: 20px;
            border: 1px solid #dee2e6;
            background: white;
            color: #6c757d;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .filter-btn.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-color: #667eea;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }

        /* آیکون‌ها */
        .survey-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), transparent);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            margin-left: 10px;
        }

        .vote-count-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #f8f9fa;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            color: #6c757d;
        }

        .vote-count-badge i {
            color: #667eea;
        }

        .text-muted {
            color: #6c757d !important;
        }
        
        /* هشدار برای نظرسنجی بسته شده */
        .closed-warning {
            background: linear-gradient(135deg, rgba(255, 193, 7, 0.1), transparent);
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid rgba(255, 193, 7, 0.2);
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #ffc107;
            font-size: 13px;
        }
        
        .closed-warning i {
            color: #ffc107;
        }
    </style>
</head>
<body>

<div class="container py-4">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center gap-3">
            <div class="user-avatar">
                {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
            </div>
            <div>
                <h4 class="mb-0">سلام {{ Auth::user()->name }} 👋</h4>
                <small class="text-muted">خوش آمدید</small>
            </div>
        </div>

        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button class="btn btn-outline-danger btn-sm d-flex align-items-center">
                <i class="fas fa-sign-out-alt ms-2"></i>
                خروج
            </button>
        </form>
    </div>

    <!-- Stats -->
    <div class="row mb-4">
        <div class="col-md-6 mb-3">
            <div class="card-box stats-card text-center">
                <h6 class="text-muted">تعداد نظرسنجی‌ها</h6>
                <h3 id="totalSurveysStat">0</h3>
                <small class="text-success">
                    <i class="fas fa-arrow-up ms-1"></i>
                    <span id="activeSurveysCount">0</span> فعال
                </small>
            </div>
        </div>

        <div class="col-md-6 mb-3">
            <div class="card-box stats-card text-center">
                <h6 class="text-muted">کل رأی‌ها</h6>
                <h3 id="totalVotesStat">0</h3>
                <small class="text-success">
                    <i class="fas fa-chart-line ms-1"></i>
                    امروز
                </small>
            </div>
        </div>
    </div>

    <!-- فیلترها -->
    <div class="card-box mb-4">
        <div class="filter-buttons justify-content-center">
            <button class="filter-btn active" data-filter="all">همه نظرسنجی‌ها</button>
            <button class="filter-btn" data-filter="active">فقط فعال</button>
            <button class="filter-btn" data-filter="closed">فقط بسته شده</button>
        </div>
    </div>

    <!-- Surveys -->
    <div class="card-box">
        <div class="d-flex align-items-center mb-4">
            <div class="survey-icon">
                <i class="fas fa-poll"></i>
            </div>
            <div>
                <h5 class="mb-1">همه نظرسنجی‌ها</h5>
                <small class="text-muted">فعال: شرکت در رأی‌گیری | بسته شده: مشاهده نتایج</small>
            </div>
        </div>

        @if($surveys->count())
            <div id="surveysList">
                @php
                    $totalVotes = 0;
                    $activeSurveysCount = 0;
                    $closedSurveysCount = 0;
                @endphp
                
                @foreach($surveys as $survey)
                    @php
                        // محاسبه آمار
                        $votes_count = $survey->votes_count ?? 0;
                        $is_active = $survey->is_active ?? false;
                        $totalVotes += $votes_count;
                        if($is_active) {
                            $activeSurveysCount++;
                        } else {
                            $closedSurveysCount++;
                        }
                        
                        // محاسبه گزینه برنده
                        $options = $survey->options ?? collect();
                        $max_votes = $options->max('votes_count') ?? 0;
                    @endphp
                    
                    <div class="survey-item {{ !$is_active ? 'closed' : '' }}" 
                         data-status="{{ $is_active ? 'active' : 'closed' }}"
                         data-survey-id="{{ $survey->id }}"
                         data-votes="{{ $votes_count }}">
                        
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <strong class="h6 mb-0">{{ $survey->title }}</strong>
                                    @if($is_active)
                                        <span class="badge-active">
                                            <i class="fas fa-play-circle ms-1"></i>فعال
                                        </span>
                                    @else
                                        <span class="badge-closed">
                                            <i class="fas fa-stop-circle ms-1"></i>بسته شده
                                        </span>
                                    @endif
                                </div>
                                
                                <p class="text-muted mb-3">
                                    {{ $survey->question }}
                                </p>
                                
                                <div class="d-flex align-items-center gap-3 mb-3">
                                    <span class="vote-count-badge">
                                        <i class="fas fa-users"></i>
                                        {{ $votes_count }} رأی
                                    </span>
                                    <span class="text-muted small">
                                        <i class="fas fa-calendar ms-1"></i>
                                        {{ $survey->created_at->format('Y/m/d') }}
                                    </span>
                                    <span class="text-muted small">
                                        <i class="fas fa-list-ol ms-1"></i>
                                        {{ count($survey->options ?? []) }} گزینه
                                    </span>
                                </div>

                                <!-- نمایش پیام برای نظرسنجی بسته شده -->
                                @if(!$is_active)
                                    <div class="closed-warning">
                                        <i class="fas fa-info-circle"></i>
                                        <span>این نظرسنجی بسته شده است. می‌توانید نتایج نهایی را مشاهده کنید.</span>
                                    </div>
                                @endif

                                <!-- بخش نتایج (برای همه نظرسنجی‌ها نمایش داده می‌شود) -->
                                @if(count($survey->options) > 0)
                                    <div class="simple-results mt-3">
                                        <div class="simple-results-header">
                                            <h6 class="mb-0">
                                                <i class="fas fa-chart-bar {{ $is_active ? 'text-primary' : 'text-secondary' }} ms-2"></i>
                                                نتایج {{ $is_active ? 'فعلی' : 'نهایی' }}
                                            </h6>
                                            @if($is_active)
                                                <small class="text-success">
                                                    <i class="fas fa-vote-yea ms-1"></i>
                                                    در حال رأی‌گیری
                                                </small>
                                            @else
                                                <small class="text-secondary">
                                                    <i class="fas fa-flag-checkered ms-1"></i>
                                                    به پایان رسیده
                                                </small>
                                            @endif
                                        </div>
                                        
                                        @foreach($survey->options as $opt)
                                            @php
                                                $opt_votes = $opt->votes_count ?? 0;
                                                $total_opt_votes = $survey->options->sum('votes_count') ?? 1;
                                                $percentage = $total_opt_votes > 0 ? round(($opt_votes / $total_opt_votes) * 100) : 0;
                                                $is_winner = $opt_votes == $max_votes && $max_votes > 0;
                                            @endphp
                                            <div class="option-result {{ $is_winner ? 'winner' : '' }}">
                                                <div class="option-text">
                                                    <span>
                                                        {{ $loop->iteration }}. {{ $opt->option_text }}
                                                        @if($is_winner && $total_opt_votes > 0)
                                                            <span class="winner-badge">
                                                                <i class="fas fa-crown"></i> برنده
                                                            </span>
                                                        @endif
                                                    </span>
                                                    <span class="fw-bold {{ $is_winner ? 'text-success' : ($is_active ? 'text-primary' : 'text-secondary') }}">
                                                        {{ $percentage }}%
                                                    </span>
                                                </div>
                                                <div class="vote-progress">
                                                    <div class="vote-progress-bar {{ $is_winner ? 'winner' : '' }}" 
                                                         style="width: {{ $percentage }}%"
                                                         data-percentage="{{ $percentage }}">
                                                    </div>
                                                </div>
                                                <div class="votes-count">
                                                    <span>{{ $opt_votes }} رأی</span>
                                                    @if($total_opt_votes > 0)
                                                        <span>{{ number_format($opt_votes / $total_opt_votes * 100, 1) }}%</span>
                                                    @else
                                                        <span>0%</span>
                                                    @endif
                                                </div>
                                            </div>
                                        @endforeach
                                        
                                        <!-- دکمه مشاهده نتایج کامل (برای همه) -->
                                        <div class="mt-3 text-center">
                                            <a href="{{ route('survey.results.public', $survey->id) }}" 
                                               class="btn {{ $is_active ? 'btn-outline-primary' : 'btn-outline-secondary' }} btn-sm">
                                                <i class="fas fa-chart-line ms-2"></i>
                                                مشاهده نتایج کامل با نمودار
                                            </a>
                                        </div>
                                    </div>
                                @endif
                            </div>
                            
                            <!-- دکمه‌های عملیاتی -->
                            <div class="survey-actions ms-3">
                                @if($is_active)
                                    <!-- برای نظرسنجی فعال: هم رأی دادن هم نتایج -->
                                    <div class="d-flex flex-column gap-2">
                                        <a href="{{ route('survey.show', $survey->id) }}"
                                           class="btn btn-vote d-flex align-items-center justify-content-center">
                                            <i class="fas fa-vote-yea ms-2"></i>
                                            رأی دادن
                                        </a>
                                        <a href="{{ route('survey.results.public', $survey->id) }}"
                                           class="results-btn d-flex align-items-center justify-content-center">
                                            <i class="fas fa-chart-bar ms-2"></i>
                                            نتایج کامل
                                        </a>
                                    </div>
                                @else
                                    <!-- برای نظرسنجی بسته: فقط مشاهده نتایج -->
                                    <div class="d-flex flex-column gap-2">
                                        <span class="text-danger small text-center">
                                            <i class="fas fa-lock ms-1"></i>
                                            نظرسنجی بسته شده
                                        </span>
                                        <a href="{{ route('survey.results.public', $survey->id) }}"
                                           class="results-btn d-flex align-items-center justify-content-center"
                                           style="background: linear-gradient(135deg, #6c757d, #495057);">
                                            <i class="fas fa-eye ms-2"></i>
                                            مشاهده نتایج نهایی
                                        </a>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
                
                <!-- ذخیره متغیرهای محاسبه شده در جاوااسکریپت -->
                <div id="surveyData" 
                     data-total-surveys="{{ $surveys->count() }}"
                     data-total-votes="{{ $totalVotes }}"
                     data-active-count="{{ $activeSurveysCount }}"
                     data-closed-count="{{ $closedSurveysCount }}"
                     style="display: none;">
                </div>
                
                <!-- آمار پایین صفحه -->
                <div class="row mt-4">
                    <div class="col-md-4 text-center">
                        <div class="card p-3">
                            <h5 class="text-primary">{{ $activeSurveysCount }}</h5>
                            <small class="text-muted">نظرسنجی فعال</small>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card p-3">
                            <h5 class="text-secondary">{{ $closedSurveysCount }}</h5>
                            <small class="text-muted">نظرسنجی بسته شده</small>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card p-3">
                            <h5 class="text-success">{{ $totalVotes }}</h5>
                            <small class="text-muted">کل رأی‌ها</small>
                        </div>
                    </div>
                </div>
            </div>
            
        @else
            <div class="empty-state">
                <i class="fas fa-poll"></i>
                <h5>هنوز نظرسنجی‌ای وجود ندارد</h5>
                <p>به زودی نظرسنجی‌های جدید اضافه خواهد شد</p>
            </div>
        @endif
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// فیلتر نظرسنجی‌ها
document.addEventListener('DOMContentLoaded', function() {
    // محاسبه آمار از داده‌های موجود
    calculateStats();
    
    // انیمیشن نوارهای پیشرفت
    animateProgressBars();
    
    const filterButtons = document.querySelectorAll('.filter-btn');
    const surveyItems = document.querySelectorAll('.survey-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // حذف کلاس active از همه دکمه‌ها
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // اضافه کردن کلاس active به دکمه کلیک شده
            this.classList.add('active');
            
            const filter = this.dataset.filter;
            let visibleCount = 0;
            
            // فیلتر کردن نظرسنجی‌ها
            surveyItems.forEach(item => {
                const status = item.dataset.status;
                
                if (filter === 'all' || filter === status) {
                    item.style.display = 'flex';
                    visibleCount++;
                } else {
                    item.style.display = 'none';
                }
            });
            
            // نمایش پیام اگر هیچ آیتمی مطابق فیلتر نباشد
            showNoResultsMessage(visibleCount);
        });
    });
});

// محاسبه آمار از داده‌های موجود
function calculateStats() {
    const surveyData = document.getElementById('surveyData');
    
    if (surveyData) {
        const totalSurveys = surveyData.dataset.totalSurveys || 0;
        const totalVotes = surveyData.dataset.totalVotes || 0;
        const activeCount = surveyData.dataset.activeCount || 0;
        const closedCount = surveyData.dataset.closedCount || 0;
        
        document.getElementById('totalSurveysStat').textContent = totalSurveys;
        document.getElementById('totalVotesStat').textContent = totalVotes;
        document.getElementById('activeSurveysCount').textContent = activeCount;
    }
}

// انیمیشن نوارهای پیشرفت
function animateProgressBars() {
    document.querySelectorAll('.vote-progress-bar').forEach(bar => {
        const percentage = bar.getAttribute('data-percentage') || 0;
        bar.style.width = '0%';
        
        setTimeout(() => {
            bar.style.width = percentage + '%';
        }, 300);
    });
}

// نمایش پیام عدم وجود نتیجه
function showNoResultsMessage(visibleCount) {
    let messageElement = document.getElementById('noResultsMessage');
    
    if (!messageElement) {
        messageElement = document.createElement('div');
        messageElement.id = 'noResultsMessage';
        messageElement.className = 'empty-state';
        messageElement.innerHTML = `
            <i class="fas fa-search"></i>
            <h5>نظرسنجی‌ای با این فیلتر یافت نشد</h5>
            <p>لطفاً فیلتر دیگری را انتخاب کنید</p>
        `;
        document.getElementById('surveysList').appendChild(messageElement);
    }
    
    if (visibleCount === 0) {
        messageElement.style.display = 'block';
    } else {
        messageElement.style.display = 'none';
    }
}

// نمایش اولیه همه نظرسنجی‌ها
window.onload = function() {
    // همه نظرسنجی‌ها به طور پیش‌فرض نمایش داده می‌شوند
    document.querySelectorAll('.survey-item').forEach(item => {
        item.style.display = 'flex';
    });
};
</script>

</body>
</html>