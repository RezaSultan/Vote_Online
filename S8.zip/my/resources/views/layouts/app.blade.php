<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>سامانه نظرسنجی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="{{ route('survey.index') }}">نظرسنجی</a>

        <div class="ms-auto">
            @auth
                <span class="me-3">سلام، {{ Auth::user()->name }}</span>
                <form class="d-inline" method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn btn-outline-danger btn-sm">خروج</button>
                </form>
            @else
                <a href="{{ route('login') }}" class="btn btn-outline-primary btn-sm me-2">ورود</a>
                <a href="{{ route('register') }}" class="btn btn-primary btn-sm">ثبت نام</a>
            @endauth
        </div>
    </div>
</nav>

<div class="container my-4">
    @yield('content')
</div>

</body>
</html>
