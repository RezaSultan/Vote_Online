<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت نام</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Vazirmatn', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            width: 100%;
            max-width: 450px;
            position: relative;
        }

        .form-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 20px;
            text-align: center;
            position: relative;
        }

        .form-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .form-header p {
            opacity: 0.9;
            font-size: 16px;
        }

        .form-body {
            padding: 40px 30px;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 15px;
        }

        .form-group input {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #e1e5ee;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
        }

        .form-group input:focus {
            border-color: #667eea;
            background-color: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            outline: none;
        }

        .form-group img {
            position: absolute;
            left: 15px;
            top: 43px;
            width: 20px;
            height: 20px;
        }

        .password-toggle {
            position: absolute;
            left: 15px;
            top: 43px;
            cursor: pointer;
            width: 20px;
            height: 20px;
        }

        .password-requirements {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
            line-height: 1.5;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 15px;
            width: 100%;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn:active {
            transform: translateY(0);
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            color: #666;
            font-size: 15px;
        }

        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .form-footer {
            text-align: center;
            padding: 20px;
            background-color: #f8f9fa;
            border-top: 1px solid #e1e5ee;
            font-size: 14px;
            color: #666;
        }

        .form-footer a {
            color: #667eea;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

        .error-container {
            background-color: #f8d7da;
            color: #721c24;
            border-right: 5px solid #dc3545;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .error-container strong {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
        }

        .error-container ul {
            list-style-type: none;
            padding-right: 0;
        }

        .error-container li {
            margin-bottom: 5px;
            position: relative;
            padding-right: 25px;
        }

        .error-container li:before {
            content: "×";
            position: absolute;
            right: 0;
            color: #dc3545;
            font-weight: bold;
            font-size: 18px;
        }

        @media (max-width: 480px) {
            .form-body {
                padding: 30px 20px;
            }
            
            .form-header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-header">
            <h1>ثبت‌نام کاربر</h1>
            <p>اطلاعات خود را برای ایجاد حساب کاربری وارد کنید</p>
        </div>
        
        <div class="form-body">
            @if ($errors->any())
                <div class="error-container">
                    <strong>خطا در ثبت‌نام!</strong>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ url('/register') }}" method="POST">
                @csrf

                <div class="form-group">
                    <label for="name">نام و نام خانوادگی</label>
                    <img src="https://cdn-icons-png.flaticon.com/512/64/64572.png" alt="نام کاربری">
                    <input type="text" id="name" name="name" placeholder="نام و نام خانوادگی خود را وارد کنید" required value="{{ old('name') }}">
                </div>
                
                <div class="form-group">
                    <label for="email">ایمیل</label>
                    <img src="https://cdn-icons-png.flaticon.com/512/561/561127.png" alt="ایمیل">
                    <input type="email" id="email" name="email" placeholder="example@email.com" required value="{{ old('email') }}">
                </div>
                
                <div class="form-group">
                    <label for="password">رمز عبور</label>
                    <img src="https://cdn-icons-png.flaticon.com/512/2889/2889676.png" alt="رمز عبور">
                    <input type="password" id="password" name="password" placeholder="رمز عبور خود را وارد کنید" required>
                    <img src="https://cdn-icons-png.flaticon.com/512/709/709612.png" alt="نمایش رمز" class="password-toggle" id="togglePassword">
                    <div class="password-requirements">
                        رمز عبور باید حداقل ۸ کاراکتر و شامل حروف بزرگ، کوچک و عدد باشد
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">تایید رمز عبور</label>
                    <img src="https://cdn-icons-png.flaticon.com/512/2889/2889676.png" alt="تایید رمز عبور">
                    <input type="password" id="confirmPassword" name="password_confirmation" placeholder="رمز عبور را مجددا وارد کنید" required>
                    <img src="https://cdn-icons-png.flaticon.com/512/709/709612.png" alt="نمایش رمز" class="password-toggle" id="toggleConfirmPassword">
                </div>
                
                <button type="submit" class="btn">ثبت‌نام</button>
                
                <div class="login-link">
                    حساب کاربری دارید؟ <a href="{{ route('login') }}">ورود</a>
                </div>
            </form>
        </div>
        
        <div class="form-footer">
            با ثبت‌نام در سایت، <a href="#">شرایط استفاده</a> و <a href="#">سیاست حریم خصوصی</a> ما را می‌پذیرید.
        </div>
    </div>

    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            // Toggle the eye icon
            this.src = type === 'password' 
                ? 'https://cdn-icons-png.flaticon.com/512/709/709612.png' 
                : 'https://cdn-icons-png.flaticon.com/512/2767/2767146.png';
        });

        document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const type = confirmPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            confirmPasswordInput.setAttribute('type', type);
            
            // Toggle the eye icon
            this.src = type === 'password' 
                ? 'https://cdn-icons-png.flaticon.com/512/709/709612.png' 
                : 'https://cdn-icons-png.flaticon.com/512/2767/2767146.png';
        });
    </script>
</body>
</html>