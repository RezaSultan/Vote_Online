@extends('layouts.app')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-8">

        <div class="card mb-3">
            <div class="card-header">
                <h4 class="mb-0">{{ $survey->title }}</h4>
            </div>

            <div class="card-body">
                @if(session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif

                @if(session('error'))
                    <div class="alert alert-danger">{{ session('error') }}</div>
                @endif

                <p>{{ $survey->question }}</p>

                <form action="{{ route('survey.vote', $survey->id) }}" method="POST">
                    @csrf

                    @foreach($survey->options as $option)
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" id="opt{{ $option->id }}" name="option_id" value="{{ $option->id }}" required>
                            <label class="form-check-label" for="opt{{ $option->id }}">
                                {{ $option->option_text }}
                            </label>
                            <span class="text-muted ms-2"> ({{ $option->votes_count ?? 0 }} رأی)</span>
                        </div>
                    @endforeach

                    <div class="mt-3">
                        <button class="btn btn-success">ثبت رأی</button>
                    </div>
                </form>
            </div>
        </div>
@if(!$survey->is_active)
    <div class="alert alert-warning text-center">
        این نظرسنجی بسته شده است و امکان رأی‌دادن وجود ندارد.
    </div>
@else
    {{-- فرم رأی --}}
@endif

        <div class="card">
            <div class="card-header">
                نتایج فعلی
            </div>
            <div class="card-body">
                @foreach($survey->options as $opt)
                    <div class="mb-2">
                        <strong>{{ $opt->option_text }}</strong>
                        <div>{{ $opt->votes_count ?? 0 }} رأی</div>
                    </div>
                @endforeach
            </div>
        </div>

    </div>
</div>

@endsection
